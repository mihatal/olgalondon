#!/usr/bin/env python3
"""Расшифровка аудио и видео прямо на компьютере (Whisper large-v3-turbo: на Mac M через MLX, на Windows через faster-whisper).

Использование:
  .agents/run transcribe/scripts/transcribe.py ФАЙЛ [ФАЙЛ ...] [опции]
  .agents/run transcribe/scripts/transcribe.py --warmup

Опции:
  --language ru|en|auto   язык речи (по умолчанию ru; auto = определить самому)
  --prompt "Школа Звезда, сольфеджио"   имена и термины, чтобы Whisper писал их правильно
  --out-dir ПАПКА         куда класть результат (по умолчанию см. ниже)
  --force                 перерасшифровать, даже если результат уже есть
  --warmup                только скачать модель (один раз при установке)

Куда кладёт: рядом с файлом. Если файл лежит в папке «исходник», то в соседнюю
папку «расшифровка», потому что «исходник» не трогаем.

Что создаёт для ФАЙЛ.ext:
  ФАЙЛ.txt          текст абзацами с метками [ММ:СС], для чтения
  ФАЙЛ.srt          субтитры по фразам
  ФАЙЛ_words.json   каждое слово с началом и концом (для монтажа)
  ФАЙЛ_silence.json карта тишины из звука (для монтажа и снапа границ)
В stdout печатает JSON со сводкой. Коды выхода: 0 готово, 2 неверные аргументы,
3 нет ffmpeg, 4 файл не найден или без звука, 5 ошибка распознавания.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

# Порог тишины: -35 дБ отделяет паузу от тихой речи в записях с петлички и Zoom,
# 0,3 с — короче этого паузы в речи не слышны как паузы.
SILENCE_DB = -35
SILENCE_MIN = 0.3
# Фразы, которые Whisper выдумывает на тишине и музыке в русских записях.
HALLUCINATIONS = [
    r"субтитр\w* (сделал|делал|создавал|подогнал)", r"редактор субтитров", r"корректор",
    r"продолжение следует", r"спасибо за (просмотр|внимание)\.?$", r"подписывайтесь на (канал|наш)",
    r"dimatorzok", r"amara\.org", r"ставьте лайк",
]
HALL_RE = re.compile("|".join(HALLUCINATIONS), re.IGNORECASE)


def die(code, msg):
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False))
    print("ОШИБКА: " + msg, file=sys.stderr)
    sys.exit(code)


def ffmpeg_bin():
    return studio.tool("ffmpeg")


def media_duration(ff, path):
    probe = ff.replace("ffmpeg", "ffprobe")
    if os.path.exists(probe):
        r = subprocess.run([probe, "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=nw=1:nk=1", str(path)], capture_output=True, text=True)
        try:
            return float(r.stdout.strip())
        except ValueError:
            pass
    return None


def extract_audio(ff, src, wav):
    r = subprocess.run([ff, "-v", "error", "-y", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000",
                        "-f", "wav", str(wav)], capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(wav) or os.path.getsize(wav) < 2000:
        die(4, f"не удалось достать звук из {src}: {r.stderr.strip()[-300:]}")


def silence_map(ff, wav):
    r = subprocess.run([ff, "-hide_banner", "-nostats", "-i", str(wav), "-af",
                        f"silencedetect=noise={SILENCE_DB}dB:d={SILENCE_MIN}", "-f", "null", "-"],
                       capture_output=True, text=True)
    out, cur = [], None
    for line in r.stderr.splitlines():
        m = re.search(r"silence_start: (-?[\d.]+)", line)
        if m:
            cur = max(0.0, float(m.group(1)))
            continue
        m = re.search(r"silence_end: ([\d.]+)", line)
        if m and cur is not None:
            end = float(m.group(1))
            out.append({"start": round(cur, 3), "end": round(end, 3), "dur": round(end - cur, 3)})
            cur = None
    return out


def ts(t, srt=True):
    t = max(0.0, t)
    h, rem = divmod(t, 3600)
    m, s = divmod(rem, 60)
    if srt:
        return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{int(round((s - int(s)) * 1000)) % 1000:03d}"
    return f"{int(h)}:{int(m):02d}:{int(s):02d}" if h else f"{int(m):02d}:{int(s):02d}"


def clean_segments(segments):
    """Убирает галлюцинации и зацикленные повторы."""
    kept, prev_text, repeats = [], None, 0
    for s in segments:
        text = (s.get("text") or "").strip()
        if not text or HALL_RE.search(text):
            continue
        if s.get("no_speech_prob", 0) > 0.6 and s.get("avg_logprob", 0) < -1.0:
            continue
        repeats = repeats + 1 if text == prev_text else 0
        prev_text = text
        if repeats >= 2:          # одна и та же фраза третий раз подряд: петля Whisper
            continue
        kept.append(s)
    return kept


def split_for_srt(seg, max_chars=84):
    """Длинный сегмент режет на строки субтитров по словам."""
    words = seg.get("words") or []
    if not words or len(seg["text"]) <= max_chars:
        return [(seg["start"], seg["end"], seg["text"].strip())]
    out, cur = [], []
    for w in words:
        cur.append(w)
        line = "".join(x["word"] for x in cur).strip()
        if len(line) >= max_chars * 0.8 and re.search(r"[.,!?…:;]$", line) or len(line) >= max_chars:
            out.append((cur[0]["start"], cur[-1]["end"], line))
            cur = []
    if cur:
        out.append((cur[0]["start"], cur[-1]["end"], "".join(x["word"] for x in cur).strip()))
    return out


def default_out_dir(src):
    parent = src.parent
    if parent.name.lower() == "исходник":
        return parent.parent / "расшифровка"
    return parent


def transcribe_one(ff, src, args):
    src = Path(src).expanduser()
    if not src.exists():
        die(4, f"файл не найден: {src}")
    out_dir = Path(args.out_dir).expanduser() if args.out_dir else default_out_dir(src)
    out_dir.mkdir(parents=True, exist_ok=True)
    base = out_dir / src.stem
    paths = {k: Path(f"{base}{suf}") for k, suf in
             (("txt", ".txt"), ("srt", ".srt"), ("words", "_words.json"), ("silence", "_silence.json"))}
    if paths["words"].exists() and not args.force:
        return {"file": str(src), "skipped": "уже расшифрован (добавь --force, чтобы заново)",
                **{k: str(v) for k, v in paths.items()}}

    with tempfile.TemporaryDirectory() as td:
        wav = Path(td) / "a.wav"
        print(f">> Достаю звук: {src.name}", file=sys.stderr)
        extract_audio(ff, src, wav)
        print(">> Карта тишины", file=sys.stderr)
        silences = silence_map(ff, wav)
        print(f">> Распознаю речь ({studio.asr_speed_hint()})", file=sys.stderr)
        try:
            res = studio.transcribe(wav, language=None if args.language == "auto" else args.language,
                                   prompt=args.prompt or None)
        except Exception as e:  # noqa: BLE001
            die(5, f"распознавание упало: {e}")

    segs = clean_segments(res.get("segments", []))
    words = []
    for s in segs:
        for w in s.get("words") or []:
            t = w["word"].strip()
            if t:
                words.append({"start": round(w["start"], 3), "end": round(w["end"], 3), "word": t,
                              "prob": round(w.get("probability", 0.0), 3)})
    duration = media_duration(ff, src)

    with open(paths["words"], "w", encoding="utf-8") as f:
        json.dump(words, f, ensure_ascii=False, indent=1)
    with open(paths["silence"], "w", encoding="utf-8") as f:
        json.dump({"source": str(src), "duration": duration, "noise_db": SILENCE_DB,
                   "min_dur": SILENCE_MIN, "silences": silences}, f, ensure_ascii=False, indent=1)
    with open(paths["srt"], "w", encoding="utf-8") as f:
        n = 0
        for s in segs:
            for a, b, line in split_for_srt(s):
                n += 1
                f.write(f"{n}\n{ts(a)} --> {ts(b)}\n{line}\n\n")
    with open(paths["txt"], "w", encoding="utf-8") as f:
        para, para_start, last_end = [], None, 0.0
        for s in segs:
            gap = s["start"] - last_end
            if para and (gap > 1.5 or sum(len(x) for x in para) > 600):
                f.write(f"[{ts(para_start, False)}] {' '.join(para)}\n\n")
                para = []
            if not para:
                para_start = s["start"]
            para.append(s["text"].strip())
            last_end = s["end"]
        if para:
            f.write(f"[{ts(para_start, False)}] {' '.join(para)}\n")

    low = sum(1 for w in words if w["prob"] < 0.4)
    return {"file": str(src), "language": res.get("language"), "duration_sec": duration,
            "word_count": len(words), "low_confidence_words": low, "pauses_over_1s": sum(1 for s in silences if s["dur"] > 1),
            **{k: str(v) for k, v in paths.items()}}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="*")
    ap.add_argument("--language", default="ru")
    ap.add_argument("--prompt", default="")
    ap.add_argument("--out-dir")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--warmup", action="store_true")
    args = ap.parse_args()
    ff = ffmpeg_bin()

    if args.warmup:
        model = studio.warmup()
        print(json.dumps({"ok": True, "model": model, "cache": os.environ.get("HF_HOME")}, ensure_ascii=False))
        return
    if not args.files:
        die(2, "не указан файл. Пример: .agents/run transcribe/scripts/transcribe.py \"Входящие/запись.m4a\"")
    results = [transcribe_one(ff, f, args) for f in args.files]
    print(json.dumps({"ok": True, "results": results}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
