#!/usr/bin/env python3
"""Кадры из видео с сеткой в долях кадра, чтобы выбрать кадрирование рилза глазами.

Использование:
  .agents/run reels-workflow/scripts/frame_grid.py ВИДЕО --at 133,145,157 [--out ФАЙЛ.jpg]

  --at   секунды исходника через запятую: бери начало, середину и конец куска рилза,
         так видно, куда смещается лицо (по умолчанию 10)
  --out  куда сохранить (по умолчанию «расшифровка/ИМЯ_grid.jpg» в папке задачи)

Как читать сетку и выбирать параметры render_reel.py:
  --crop-x, --crop-y  центр лица в долях ВСЕГО кадра исходника (0.0 левый/верхний край, 1.0 правый/нижний).
                      Если лицо двигается между кадрами, бери среднее.
  --zoom              во сколько раз увеличить: 1.0 = вся высота исходника в окне видео рилза,
                      2.0 = половина высоты. Плитка Zoom в сетке 2×2 или с презентацией: 2.5–3.2.
                      Видимая область по высоте = 1/zoom; подписи Zoom («Ольга Лондон», «закрепление»)
                      держи за её краем.
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402
from PIL import Image, ImageDraw

ff = studio.tool("ffmpeg")
ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("video", help="исходное видео")
ap.add_argument("--at", default="10", help="секунды через запятую, например 133,145,157")
ap.add_argument("--out", help="путь к JPG (по умолчанию в «расшифровка» папки задачи)")
a = ap.parse_args()
src = Path(a.video)
if a.out:
    out = Path(a.out)
else:
    base = src.parent.parent / "расшифровка" if src.parent.name.lower() == "исходник" else src.parent
    base.mkdir(parents=True, exist_ok=True)
    out = base / f"{src.stem}_grid.jpg"
times = [float(x) for x in a.at.split(",") if x.strip()]
tiles = []
with tempfile.TemporaryDirectory() as td:
    for k, t in enumerate(times):
        p = Path(td) / f"f{k}.png"
        subprocess.run([ff, "-v", "error", "-y", "-ss", str(t), "-i", str(src), "-frames:v", "1", "-vf", "scale=960:-2", str(p)], check=True)
        im = Image.open(p).convert("RGB")
        d = ImageDraw.Draw(im)
        W, H = im.size
        for i in range(1, 10):
            x, y = W * i / 10, H * i / 10
            d.line([(x, 0), (x, H)], fill=(255, 157, 183), width=1)
            d.line([(0, y), (W, y)], fill=(255, 157, 183), width=1)
            d.text((x + 3, 3), f"{i/10:.1f}", fill=(255, 255, 0))
            d.text((3, y + 3), f"{i/10:.1f}", fill=(255, 255, 0))
        d.rectangle([0, H - 22, 120, H], fill=(0, 0, 0))
        d.text((6, H - 18), f"t = {t:g} с", fill=(255, 255, 255))
        tiles.append(im)
W, H = tiles[0].size
sheet = Image.new("RGB", (W, H * len(tiles)), "black")
for k, im in enumerate(tiles):
    sheet.paste(im, (0, k * H))
sheet.save(out, quality=88)
print(json.dumps({"ok": True, "frame": str(out), "at": times,
                  "next": "Посмотри картинку и выбери --crop-x, --crop-y (центр лица, доли кадра) и --zoom для render_reel.py"},
                 ensure_ascii=False))
