#!/usr/bin/env python3
"""Рендер вертикального рилза 1080×1920 в фирстиле школы (стиль из assets/style.json, его собирает znakomstvo/apply_brand.py): точная нарезка, хук, субтитры по словам, призыв.

Использование:
  .agents/run reels-workflow/scripts/render_reel.py ВИДЕО --words ИМЯ_words.json --segments 85.2-129.4 \\
      --hook "Текст хука" [опции]

Опции:
  --segments A-B[,C-D...]  куски исходника в секундах (после snap.py); несколько = монтажная склейка
  --id R1                  имя рилза (по умолчанию reel)
  --hook "..."             текст хука, 5–8 слов (показывается первые 5–12 с)
  --cta "..."              призыв (по умолчанию нет; появляется с 20-й секунды или за 5 с до конца)
  --layout split|full      split: видео сверху, текст на вине (по умолчанию) · full: видео на весь кадр
  --crop-x 0.5 --crop-y 0.5  центр кадрирования в долях кадра (0 левый/верхний край, 1 правый/нижний)
  --zoom 1.0               увеличение: 2.2 вытащит одну плитку Zoom из сетки
  --speed 1.1              ускорение (база 1.1; 1.0 без ускорения)
  --style ФАЙЛ             файл стиля (по умолчанию assets/style.json)
  --out ФАЙЛ               по умолчанию «готово/ID.mp4» рядом с папкой «исходник»
  --preview                быстрый черновик 540×960 для согласования образца
  --no-subs                без субтитров

Создаёт: ID.mp4, ID_cover.png (кадр с хуком, ставится обложкой в Instagram), ID_check.jpg (4 кадра на проверку).\n  С --preview: половинное разрешение 540×960, файлы с суффиксом _preview (ID_preview.mp4, ID_preview_check.jpg).
Коды: 0 готово, 2 ошибка аргументов, 3 нет ffmpeg/шрифтов, 5 рендер упал.
"""
import argparse
import json
import math
import os
import random
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve()
STUDIO = HERE.parents[4]
CUT = HERE.parents[2] / "video-edit-pipeline" / "scripts" / "cut.py"


def die(code, msg):
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False))
    print("ОШИБКА: " + msg, file=sys.stderr)
    sys.exit(code)


def tool(name):
    return studio.tool(name)


FF, FP = tool("ffmpeg"), tool("ffprobe")


def hexrgb(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


class Fonts:
    def __init__(self, style):
        self.style, self.cache = style, {}
        for key, rel in style["fonts"].items():
            if not (STUDIO / rel).exists():
                die(3, f"нет шрифта {rel}. Запусти скилл znakomstvo: шрифты школы ещё не скачаны")

    def get(self, key, size):
        k = (key, size)
        if k not in self.cache:
            f = ImageFont.truetype(str(STUDIO / self.style["fonts"][key]), size)
            want = self.style.get("font_axes", {}).get(key, {})
            try:
                axes = f.get_variation_axes()
                vec = []
                for ax in axes:
                    name = ax["name"].decode() if isinstance(ax["name"], bytes) else str(ax["name"])
                    val = next((v for n, v in want.items() if n in name.lower()), ax["default"])
                    vec.append(max(ax["minimum"], min(ax["maximum"], val)))
                f.set_variation_by_axes(vec)
            except Exception:  # noqa: BLE001  (статичный шрифт без осей)
                pass
            self.cache[k] = f
        return self.cache[k]


def text_w(font, s):
    return font.getlength(s)


def wrap(font, text, max_w, max_lines):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if text_w(font, t) <= max_w:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    ok = len(lines) <= max_lines and all(text_w(font, ln) <= max_w for ln in lines)
    return lines, ok


def fit(fonts, key, text, max_w, fs_max, fs_min, max_lines):
    for fs in range(fs_max, fs_min - 1, -2):
        f = fonts.get(key, fs)
        lines, ok = wrap(f, text, max_w, max_lines)
        if ok:
            return f, lines
    f = fonts.get(key, fs_min)
    return f, wrap(f, text, max_w, 99)[0]


def wavy(draw, x0, x1, y, color, width=8, amp=7, step=34, seed=3):
    rnd = random.Random(seed)
    pts, x = [], x0
    while x <= x1:
        pts.append((x, y + amp * math.sin((x - x0) / step * math.pi) + rnd.uniform(-1.5, 1.5)))
        x += 6
    draw.line(pts, fill=color, width=width, joint="curve")


def draw_hook(img, fonts, cfg, colors, text):
    d = ImageDraw.Draw(img)
    f, lines = fit(fonts, "head", text.upper(), cfg["max_w"], cfg["fs_max"], cfg["fs_min"], cfg["lines"])
    asc, desc = f.getmetrics()
    lh = int((asc + desc) * 0.92)
    total = lh * len(lines)
    y = cfg["y"] - total // 2
    W = img.width
    if cfg.get("plate"):
        wmax = max(text_w(f, ln) for ln in lines)
        pad_x, pad_y = 34, 22
        d.rounded_rectangle([W / 2 - wmax / 2 - pad_x, y - pad_y, W / 2 + wmax / 2 + pad_x, y + total + pad_y],
                            radius=14, fill=hexrgb(colors[cfg["plate"]]))
    for ln in lines:
        d.text((W / 2, y + lh / 2), ln, font=f, fill=hexrgb(colors[cfg["color"]]), anchor="mm")
        y += lh
    if cfg.get("underline"):
        lw = text_w(f, lines[-1])
        wavy(d, W / 2 - lw / 2, W / 2 + lw / 2, y + 10, hexrgb(colors[cfg["underline"]]))


def draw_subs(img, fonts, cfg, colors, words, active):
    d = ImageDraw.Draw(img)
    text = " ".join(words)
    f, lines = fit(fonts, "head", text, cfg["max_w"], cfg["fs_max"], cfg["fs_min"], cfg.get("lines", 1))
    asc, desc = f.getmetrics()
    lh = int((asc + desc) * 0.95)
    y = cfg["y"] - lh * len(lines) / 2
    idx = 0
    stroke = cfg.get("stroke")
    for ln in lines:
        parts = ln.split()
        space = text_w(f, " ")
        total = sum(text_w(f, p) for p in parts) + space * (len(parts) - 1)
        x = img.width / 2 - total / 2
        for p in parts:
            col = colors[cfg["active"]] if idx == active else colors[cfg["color"]]
            kw = {"stroke_width": 6, "stroke_fill": hexrgb(colors[stroke])} if stroke else {}
            d.text((x, y + lh / 2), p, font=f, fill=hexrgb(col), anchor="lm", **kw)
            x += text_w(f, p) + space
            idx += 1
        y += lh


def draw_cta(img, fonts, cfg, colors, text):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    f = fonts.get("mark", cfg["fs"])
    lines, _ = wrap(f, text, cfg["max_w"], 3)
    asc, desc = f.getmetrics()
    lh = int((asc + desc) * 0.95)
    y = cfg["y"] - lh * len(lines) / 2
    kw = {"stroke_width": 4, "stroke_fill": hexrgb(colors[cfg["stroke"]])} if cfg.get("stroke") else {}
    for ln in lines:
        d.text((img.width / 2, y + lh / 2), ln, font=f, fill=hexrgb(colors[cfg["color"]]), anchor="mm", **kw)
        y += lh
    if cfg.get("rotate"):
        layer = layer.rotate(-cfg["rotate"], resample=Image.BICUBIC, center=(img.width / 2, cfg["y"]))
    img.alpha_composite(layer)


def background(style, layout, size):
    color = hexrgb(style["colors"][layout["background"]])
    img = Image.new("RGBA", size, color)
    # зерно как на макетах: мелкий шум ±4 по яркости, почти незаметный, но убирает «пластиковую» заливку
    rnd = random.Random(7)
    px = img.load()
    for _ in range(size[0] * size[1] // 9):
        x, y = rnd.randrange(size[0]), rnd.randrange(size[1])
        r, g, b, a = px[x, y]
        k = rnd.randint(-5, 5)
        px[x, y] = (max(0, min(255, r + k)), max(0, min(255, g + k)), max(0, min(255, b + k)), a)
    return img


def chunk_words(ws, cfg):
    groups, cur = [], []
    for i, w in enumerate(ws):
        if cur:
            gap = w["start"] - cur[-1]["end"]
            chars = sum(len(x["text"]) + 1 for x in cur) + len(w["text"])
            if (len(cur) >= cfg["max_words"] or chars > cfg["max_chars"] or gap > cfg["break_gap"]
                    or cur[-1]["raw"].rstrip()[-1:] in ".!?…:;,"):
                groups.append(cur)
                cur = []
        cur.append(w)
    if cur:
        groups.append(cur)
    return groups


def probe_dur(p):
    r = subprocess.run([FP, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(p)],
                       capture_output=True, text=True)
    return float(r.stdout.strip() or 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--words", required=True)
    ap.add_argument("--segments", required=True)
    ap.add_argument("--id", default="reel")
    ap.add_argument("--hook", default="")
    ap.add_argument("--cta", default="")
    ap.add_argument("--layout", choices=["split", "full"], default="split")
    ap.add_argument("--crop-x", type=float, default=0.5)
    ap.add_argument("--crop-y", type=float, default=0.5)
    ap.add_argument("--zoom", type=float, default=1.0)
    ap.add_argument("--speed", type=float)
    ap.add_argument("--style", default=str(HERE.parents[1] / "assets" / "style.json"))
    ap.add_argument("--out")
    ap.add_argument("--preview", action="store_true")
    ap.add_argument("--no-subs", action="store_true")
    args = ap.parse_args()
    studio.load_brand()  # без знакомства стиль рилзов не собран

    style = json.load(open(args.style, encoding="utf-8"))
    colors, layout = style["colors"], style["layouts"][args.layout]
    speed = args.speed or style.get("speed", 1.0)
    W, H = style["canvas"]
    fps = style["fps"]
    src = Path(args.video).expanduser()
    if not src.exists():
        die(2, f"нет файла {src}")
    try:
        segs = [tuple(float(x) for x in part.split("-")) for part in args.segments.split(",")]
    except ValueError:
        die(2, "--segments в формате 85.2-129.4 или 10-20,35.5-50")
    fonts = Fonts(style)
    # preflight: слова обязаны быть от этого же файла (иначе субтитры уедут). Сверяем длину.
    src_dur = probe_dur(src)
    wlist = json.load(open(args.words, encoding="utf-8"))
    if wlist and wlist[-1]["end"] > src_dur + 2:
        die(2, f"words.json длиннее видео ({wlist[-1]['end']:.0f} с против {src_dur:.0f} с): расшифровка от другого файла. "
               "Расшифруй именно этот файл скиллом transcribe.")
    for a, b in segs:
        if not (0 <= a < b <= src_dur + 0.5):
            die(2, f"кусок {a}-{b} вне видео длиной {src_dur:.1f} с")
    out = Path(args.out) if args.out else (
        (src.parent.parent / "готово" if src.parent.name.lower() == "исходник" else src.parent) / f"{args.id}.mp4")
    if args.preview:
        out = out.with_name(out.stem + "_preview.mp4")
    out.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        keep = td / "keep.json"
        json.dump([{"start": a, "end": b} for a, b in segs], open(keep, "w"))
        clean = td / "clean.mp4"
        print(">> Нарезка кусков", file=sys.stderr)
        r = subprocess.run([sys.executable, str(CUT), str(src), "--keep", str(keep), "--out", str(clean),
                            "--speed", str(speed)], capture_output=True, text=True)
        if r.returncode != 0:
            die(5, "нарезка упала: " + (r.stdout[-300:] or r.stderr[-300:]))
        table = json.load(open(td / "clean_joins.json"))["table"]
        D = probe_dur(clean)

        # слова → время рилза
        words = json.load(open(args.words, encoding="utf-8"))
        ws = []
        for row in table:
            for w in words:
                if row["src_start"] - 0.02 <= w["start"] < row["src_end"]:
                    a = row["out_start"] + (w["start"] - row["src_start"]) / speed
                    b = row["out_start"] + (min(w["end"], row["src_end"]) - row["src_start"]) / speed
                    raw = w["word"].strip()
                    text = raw.strip(",.;:…").strip()
                    # Whisper режет «что-то» на «что» + «-то» и отрывает знаки: приклеиваем к прошлому слову
                    if ws and (raw.startswith("-") or not any(ch.isalnum() for ch in raw)):
                        ws[-1]["text"] = (ws[-1]["text"] + text).strip()
                        ws[-1]["raw"] += raw
                        ws[-1]["end"] = max(ws[-1]["end"], b)
                        continue
                    if text:
                        ws.append({"start": max(0, a), "end": max(a + 0.05, b), "text": text, "raw": raw})
        groups = [] if args.no_subs else chunk_words(ws, style["subs"])

        ht = style["hook_time"]
        hook_end = min(ht["max"], max(ht["min"], D * ht["share"])) if args.hook else 0
        cta_start = (style["cta_from"] if D > style["cta_from"] + 4 else max(0, D - 5)) if args.cta else D + 1

        # состояния: (группа, активное слово) на отрезках времени
        events = []
        hold = style["subs"]["hold_after"]
        for gi, g in enumerate(groups):
            nxt = groups[gi + 1][0]["start"] if gi + 1 < len(groups) else D
            for wi, w in enumerate(g):
                a = w["start"] if wi else g[0]["start"]
                b = g[wi + 1]["start"] if wi + 1 < len(g) else min(nxt, w["end"] + hold)
                if b > a:
                    events.append((a, b, gi, wi))
        cuts = sorted({0.0, D, hook_end, cta_start, *[e[0] for e in events], *[e[1] for e in events]})
        cuts = [c for c in cuts if 0 <= c <= D]

        print(f">> Рисую текст: {len(events)} состояний субтитров", file=sys.stderr)
        bg = background(style, layout, (W, H))
        bg_path = td / "bg.png"
        bg.save(bg_path)
        cache, timeline = {}, []
        for a, b in zip(cuts, cuts[1:]):
            if b - a < 1 / fps / 2:
                continue
            mid = (a + b) / 2
            ev = next((e for e in events if e[0] <= mid < e[1]), None)
            key = (ev[2] if ev else -1, ev[3] if ev else -1, mid < hook_end, mid >= cta_start)
            if key not in cache:
                img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                if key[2]:
                    draw_hook(img, fonts, layout["hook"], colors, args.hook)
                if key[0] >= 0:
                    draw_subs(img, fonts, layout["subs"], colors, [w["text"] for w in groups[key[0]]], key[1])
                if key[3]:
                    draw_cta(img, fonts, layout["cta"], colors, args.cta)
                p = td / f"s{len(cache):04d}.png"
                img.save(p, compress_level=1)
                cache[key] = p
            timeline.append((cache[key], b - a))
        conc = td / "ov.txt"
        with open(conc, "w") as f:
            f.write("ffconcat version 1.0\n")
            for p, dur in timeline:
                f.write(f"file '{p}'\nduration {dur:.4f}\n")
            f.write(f"file '{timeline[-1][0]}'\n")

        # кадрирование
        r = subprocess.run([FP, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                            "-of", "csv=p=0", str(clean)], capture_output=True, text=True)
        sw, sh = (int(x) for x in r.stdout.strip().split(","))
        bx, by, bw, bh = layout["video_box"]
        ch = sh / max(1.0, args.zoom)
        cw = ch * bw / bh
        if cw > sw:
            cw, ch = sw, sw * bh / bw
        cx = min(max(args.crop_x * sw - cw / 2, 0), sw - cw)
        cy = min(max(args.crop_y * sh - ch / 2, 0), sh - ch)
        crop = f"crop={int(cw) // 2 * 2}:{int(ch) // 2 * 2}:{int(cx)}:{int(cy)},scale={bw}:{bh}:flags=lanczos,setsar=1"
        scale_out = ",scale=540:960" if args.preview else ""
        fc = (f"[0:v]{crop},fps={fps}[vid];[1:v]format=rgba[bg];[bg][vid]overlay={bx}:{by}[base];"
              f"[2:v]format=rgba[ov];[base][ov]overlay=0:0:eof_action=repeat:format=auto{scale_out},format=yuv420p[v];"
              f"[0:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[a]")
        enc = (["-c:v", "h264_videotoolbox", "-b:v", "3M" if args.preview else style["video_bitrate"]]
               if "h264_videotoolbox" in subprocess.run([FF, "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
               else ["-c:v", "libx264", "-preset", "medium", "-crf", "20"])
        print(">> Собираю рилз", file=sys.stderr)
        r = subprocess.run([FF, "-v", "error", "-y", "-i", str(clean), "-loop", "1", "-framerate", str(fps), "-i", str(bg_path),
                            "-f", "concat", "-safe", "0", "-i", str(conc), "-filter_complex", fc,
                            "-map", "[v]", "-map", "[a]", "-t", f"{D:.3f}", "-r", str(fps), *enc,
                            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(out)],
                           capture_output=True, text=True)
        if r.returncode != 0:
            die(5, "сборка упала: " + r.stderr[-500:])

    # обложка: кадр с хуком (видно и лицо, и тему) — в сетке Instagram это читается; без хука последний кадр
    cover = out.with_name(out.stem + "_cover.png")
    cover_at = ["-ss", f"{min(1.5, hook_end * 0.4):.2f}"] if hook_end else ["-sseof", "-0.2"]
    subprocess.run([FF, "-v", "error", "-y", *cover_at, "-i", str(out), "-frames:v", "1", str(cover)], capture_output=True)
    sheet = out.with_name(out.stem + "_check.jpg")
    frames = []
    dur = probe_dur(out)
    with tempfile.TemporaryDirectory() as td:
        for i, t in enumerate([min(1.0, dur / 4), dur * 0.35, dur * 0.65, max(0, dur - 0.5)]):
            p = Path(td) / f"{i}.jpg"
            subprocess.run([FF, "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", str(out), "-frames:v", "1",
                            "-vf", "scale=360:-2", str(p)], capture_output=True)
            if p.exists():
                frames.append(Image.open(p).convert("RGB"))
        if frames:
            s = Image.new("RGB", (360 * len(frames), frames[0].height), "black")
            for i, im in enumerate(frames):
                s.paste(im, (i * 360, 0))
            s.save(sheet, quality=85)
    print(json.dumps({"ok": True, "out": str(out), "duration": round(dur, 2), "cover": str(cover),
                      "check_sheet": str(sheet), "subtitle_groups": len(groups), "hook_until": round(hook_end, 1),
                      "cta_from": round(cta_start, 1) if args.cta else None, "layout": args.layout,
                      "next": "Посмотри check_sheet глазами: текст не наезжает, лицо в кадре. Потом досмотри видео целиком."},
                     ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
