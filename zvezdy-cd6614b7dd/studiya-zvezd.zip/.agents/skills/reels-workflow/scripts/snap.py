#!/usr/bin/env python3
"""Подтягивает черновые границы рилзов к началу предложения и к концу мысли.

Использование:
  .agents/run reels-workflow/scripts/snap.py ИМЯ_words.json CANDIDATES.json [опции]

CANDIDATES.json: [{"id": "R1", "start": 85.0, "end": 129.0, "payoff_word_end_ts": 127.4?}, ...]
  payoff_word_end_ts (необязательно) — конец слова-развязки: снап не имеет права оборвать клип раньше.

Правила (выверены на сотнях наших рилзов):
  старт → ближайшее начало предложения (после . ! ? или паузы в звуке > 0,35 с) в окне ±1,5 с,
          плюс до 0,2 с тишины до первого слова, не залезая в предыдущее слово;
  конец → ближайшая точка, ! или ? (или пауза ≥ 0,7 с) ВПЕРЁД в окне +3 с (запятая без паузы и многоточие не граница),
          плюс 0,3 с тишины после последнего слова;
  не нашёл → не угадывает: ставит needs_manual_review с причиной.
Пишет CANDIDATES_snapped.json и печатает отчёт «было → стало» в JSON.
"""
import argparse
import json
import re
import sys
from pathlib import Path

TERMINAL = re.compile(r"[.!?…]+[\"'»)]*$")
TRAILING = re.compile(r"(\.\.\.|…)[\"'»)]*$")   # «для меня... Для меня это» — самоисправление, не конец мысли
START_WINDOW, END_WINDOW, START_PAD, END_PAD, GAP = 1.5, 3.0, 0.2, 0.3, 0.35
END_PAUSE = 0.7   # в живой речи Whisper ставит запятую почти везде: пауза ≥ 0,7 с после слова тоже конец мысли
END_BACK = 1.0    # допуск назад на неточность чернового таймкода; вперёд всегда в приоритете
FILLER_START = {"ну", "короче", "смотри", "смотрите", "вот", "как бы", "то есть", "в общем", "слушай", "значит"}


def is_terminal(t):
    t = t.strip()
    return not TRAILING.search(t) and bool(TERMINAL.search(t))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("words")
    ap.add_argument("candidates")
    ap.add_argument("--silence")
    args = ap.parse_args()
    words = [w for w in json.load(open(args.words, encoding="utf-8")) if w["word"].strip()]
    wp = Path(args.words)
    sp = Path(args.silence) if args.silence else wp.with_name(wp.name.replace("_words.json", "_silence.json"))
    silences = json.load(open(sp, encoding="utf-8"))["silences"] if sp.exists() else None
    cands = json.load(open(args.candidates, encoding="utf-8"))

    starts = [0]
    for i in range(1, len(words)):
        prev, cur = words[i - 1], words[i]
        if is_terminal(prev["word"]):
            starts.append(i)
        elif silences is not None:
            # пауза из звука, в том числе спрятанная Whisper внутри растянутого слова
            if any(s["dur"] > GAP and s["end"] > prev["start"] and s["start"] < cur["start"] for s in silences):
                starts.append(i)
        elif cur["start"] - prev["end"] > GAP:
            starts.append(i)

    def pause_after(i):
        if i + 1 >= len(words):
            return 0.0
        if silences is None:
            return words[i + 1]["start"] - words[i]["end"]
        w, nxt = words[i], words[i + 1]
        # большой промежуток без слов тоже пауза, даже если в нём шумит фон (дыхание, чужой микрофон в Zoom):
        # Whisper умеет спрятать паузу внутрь слова, но не придумывает лишнюю
        gap = nxt["start"] - w["end"]
        return max([gap] + [s["dur"] for s in silences if s["end"] > w["start"] and s["start"] < nxt["start"]])

    ends = {i for i, w in enumerate(words) if is_terminal(w["word"]) or pause_after(i) >= END_PAUSE}

    def pad_start(i):
        # тишина до первого слова, но не залезая в предыдущее слово (иначе в клип попадёт «значит,»)
        prev_end = words[i - 1]["end"] if i > 0 else 0.0
        return max(0.0, prev_end, words[i]["start"] - START_PAD)

    def first_at(t):
        return next((i for i, w in enumerate(words) if w["start"] >= t), len(words) - 1)

    results = []
    for c in cands:
        s0, e0 = float(c["start"]), float(c["end"])
        reasons, warns = [], []
        near = [i for i in starts if abs(words[i]["start"] - s0) <= START_WINDOW]
        if near:
            best = min(near, key=lambda i: abs(words[i]["start"] - s0))
            # старт на разгонном слове («значит», «ну», «смотри»): перешагиваем его, если следующее слово рядом
            while (best + 1 < len(words) and re.sub(r"[^\wё]", "", words[best]["word"].lower()) in FILLER_START
                   and words[best + 1]["start"] - s0 <= START_WINDOW):
                best += 1
            s1 = pad_start(best)
        else:
            s1 = pad_start(first_at(s0))
            reasons.append(f"начало предложения не найдено в ±{START_WINDOW} с от {s0:.2f}: подрезано по слову, проверь")
        fwd = [w for i, w in enumerate(words) if e0 <= w["end"] <= e0 + END_WINDOW and i in ends]
        back = [w for i, w in enumerate(words) if e0 - END_BACK <= w["end"] < e0 and i in ends]
        if fwd:
            e1 = min(fwd, key=lambda w: w["end"])["end"] + END_PAD
        elif back:
            e1 = max(back, key=lambda w: w["end"])["end"] + END_PAD
        else:
            idx = first_at(e0)
            if idx > 0 and words[idx]["start"] > e0:
                idx -= 1
            e1 = words[idx]["end"] + END_PAD
            reasons.append(f"конец мысли (. ! ? или пауза ≥ {END_PAUSE} с) не найден в +{END_WINDOW} с от {e0:.2f}: выбери другую точку выхода")
        payoff = c.get("payoff_word_end_ts")
        if payoff is not None and e1 < float(payoff):
            reasons.append(f"конец {e1:.2f} раньше развязки {payoff}: клип обрежет ответ на хук")
        first2 = [re.sub(r"[^\wё ]", "", w["word"].lower()) for w in words if s1 - 0.05 <= w["start"] <= s1 + 1.5][:2]
        if first2 and (first2[0] in FILLER_START or " ".join(first2) in FILLER_START):
            warns.append(f"старт с разгона «{' '.join(first2)}»: сдвинь старт на следующую фразу, если она самодостаточна")
        text = " ".join(w["word"] for w in words if s1 - 0.05 <= w["start"] <= e1 + 0.05)
        results.append({**c, "start": round(s1, 2), "end": round(e1, 2), "original_start": s0, "original_end": e0,
                        "duration": round(e1 - s1, 1), "needs_manual_review": bool(reasons),
                        "review_reason": "; ".join(reasons) or None, "warnings": warns or None,
                        "first_words": text[:90], "last_words": text[-90:]})
    out = Path(args.candidates).with_name(Path(args.candidates).stem + "_snapped.json")
    json.dump(results, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"ok": True, "file": str(out), "need_review": sum(r["needs_manual_review"] for r in results),
                      "results": results}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.exit(main())
