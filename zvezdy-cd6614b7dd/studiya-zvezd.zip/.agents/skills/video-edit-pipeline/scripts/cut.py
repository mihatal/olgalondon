#!/usr/bin/env python3
"""Точный монтаж по списку кусков: оставить нужное, склеить без щелчков и рассинхрона.

Использование:
  .agents/run video-edit-pipeline/scripts/cut.py ВИДЕО (--keep KEEP.json | --remove CUTS.json) [опции]

Входные списки:
  KEEP.json   [{"start": 12.4, "end": 40.0}, ...]  куски, которые ОСТАВЛЯЕМ (время исходника, сек)
  CUTS.json   результат find_cuts.py: вырезаются элементы с "apply": true

Опции:
  --out ФАЙЛ        куда сохранить (по умолчанию «готово/ИМЯ_clean.mp4» рядом с папкой «исходник»)
  --tighten         поджать паузы внутри кусков: тишина дольше 0,35 с → 0,25 с (нужен ИМЯ_silence.json)
  --no-snap         не подтягивать края к самой тихой точке (по умолчанию подтягиваются внутрь ≤ 0,12 с)
  --speed 1.1       ускорить (звук без «мультяшности», через atempo)
  --preview         быстрый проверочный рендер 720p (для показа, не для публикации)
  --dry-run         только проверить план и показать итог, ничего не рендерить
  --sheet           сохранить рядом лист из 6 кадров ИМЯ_check.jpg для проверки глазами
  --normalize       выровнять громкость до −14 LUFS (для публикации)

Выход: видео + ИМЯ_clean_joins.json (стыки во времени результата и таблица кусков).
В stdout JSON-сводка. Коды: 0 готово, 2 ошибка в плане (текст объясняет), 3 нет ffmpeg, 4 нет файла, 5 рендер упал.
"""
import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

import numpy as np

SNAP_MAX = 0.12      # край куска двигается только внутрь и не дальше 0,12 с: дальше начинает съедать слово
SNAP_WIN = 0.010     # окно энергии 10 мс: так находится провал между словами точнее таймкодов Whisper
FADE = 0.008         # 8 мс затухания на каждом стыке: убирает щелчок, на слух не заметно
TIGHT_OVER = 0.35    # паузы длиннее 0,35 с внутри куска поджимаются...
TIGHT_TO = 0.25      # ...до 0,25 с: ритм живой речи без «мёртвого воздуха» (правило из нашего монтажа)
MIN_SEG = 0.15       # куски короче 0,15 с отбрасываются: это обрывок, а не речь
SR = 48000


def die(code, msg):
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False))
    print("ОШИБКА: " + msg, file=sys.stderr)
    sys.exit(code)


def tool(name):
    return studio.tool(name)


FF, FP = tool("ffmpeg"), tool("ffprobe")


def probe(path):
    r = subprocess.run([FP, "-v", "error", "-show_entries",
                        "format=duration:stream=codec_type,r_frame_rate,avg_frame_rate,width,height",
                        "-of", "json", str(path)], capture_output=True, text=True)
    d = json.loads(r.stdout or "{}")
    v = next((s for s in d.get("streams", []) if s["codec_type"] == "video"), None)
    a = next((s for s in d.get("streams", []) if s["codec_type"] == "audio"), None)
    fps = 30.0
    if v:
        for key in ("avg_frame_rate", "r_frame_rate"):
            n, _, m = (v.get(key) or "0/0").partition("/")
            if m and float(m) and float(n):
                fps = float(n) / float(m)
                break
    return {"duration": float(d.get("format", {}).get("duration", 0)), "fps": fps,
            "w": v and v["width"], "h": v and v["height"], "has_video": bool(v), "has_audio": bool(a)}


def load_audio(path):
    r = subprocess.run([FF, "-v", "error", "-i", str(path), "-vn", "-ac", "2", "-ar", str(SR),
                        "-f", "f32le", "-"], capture_output=True)
    if r.returncode != 0:
        die(4, "не удалось прочитать звук: " + r.stderr.decode(errors="ignore")[-300:])
    return np.frombuffer(r.stdout, dtype=np.float32).reshape(-1, 2)


def default_out(src, preview):
    suffix = "_preview.mp4" if preview else "_clean.mp4"
    if src.parent.name.lower() == "исходник":
        return src.parent.parent / "готово" / f"{src.stem}{suffix}"
    return src.parent / f"{src.stem}{suffix}"


def load_plan(args, duration):
    if bool(args.keep) == bool(args.remove):
        die(2, "укажи ровно одно: --keep KEEP.json или --remove CUTS.json")
    data = json.load(open(args.keep or args.remove, encoding="utf-8"))
    if isinstance(data, dict):
        data = data.get("cuts") or data.get("segments") or []
    if args.keep:
        segs = [(float(x["start"]), float(x["end"])) for x in data]
    else:
        cuts = sorted((float(x["start"]), float(x["end"])) for x in data if x.get("apply"))
        segs, t = [], 0.0
        for a, b in cuts:
            if a > t:
                segs.append((t, a))
            t = max(t, b)
        if t < duration:
            segs.append((t, duration))
    errors = []
    for i, (a, b) in enumerate(segs):
        if b <= a:
            errors.append(f"кусок {i + 1}: конец {b:.2f} раньше начала {a:.2f}")
        if a < -0.01 or b > duration + 0.05:
            errors.append(f"кусок {i + 1}: {a:.2f}–{b:.2f} выходит за длину видео {duration:.2f}")
    for i in range(1, len(segs)):
        if segs[i][0] < segs[i - 1][1] - 0.01:
            errors.append(f"куски {i} и {i + 1} перекрываются: {segs[i - 1]} и {segs[i]}")
    if errors:
        die(2, "план не прошёл проверку: " + "; ".join(errors[:8]))
    return [(max(0.0, a), min(duration, b)) for a, b in segs]


def snap_inward(audio, segs):
    """Края двигаются только внутрь куска, к самому тихому окну 10 мс в пределах 0,12 с."""
    win = int(SNAP_WIN * SR)
    mono = np.abs(audio).mean(axis=1)
    out = []
    for a, b in segs:
        def quietest(lo, hi):
            i0, i1 = int(lo * SR), int(hi * SR)
            if i1 - i0 < win * 2:
                return None
            chunk = mono[i0:i1]
            n = len(chunk) // win
            energy = chunk[: n * win].reshape(n, win).mean(axis=1)
            return lo + (int(np.argmin(energy)) + 0.5) * SNAP_WIN
        na = quietest(a, min(a + SNAP_MAX, b)) if b - a > 2 * SNAP_MAX else None
        nb = quietest(max(b - SNAP_MAX, a), b) if b - a > 2 * SNAP_MAX else None
        out.append((na if na is not None else a, nb if nb is not None else b))
    return out


def tighten(segs, silences):
    """Внутри кусков вырезает середину длинных пауз, оставляя 0,25 с тишины."""
    out = []
    for a, b in segs:
        cur = a
        for s in silences:
            if s["dur"] <= TIGHT_OVER or s["start"] < a or s["end"] > b:
                continue
            cut_a = s["start"] + TIGHT_TO / 2
            cut_b = s["end"] - TIGHT_TO / 2
            if cut_a - cur >= MIN_SEG:
                out.append((cur, cut_a))
                cur = cut_b
        out.append((cur, b))
    return out


def quantize(segs, fps):
    """Границы к целым кадрам внутрь: так звук и видео режутся в одних и тех же точках."""
    q = []
    for a, b in segs:
        fa, fb = math.ceil(a * fps - 1e-6), math.floor(b * fps + 1e-6)
        if (fb - fa) / fps >= MIN_SEG:
            q.append((fa, fb))
    return q


def render_video_seg(src, fa, fb, fps, path, preview, speed):
    vf = []
    if preview:
        vf.append("scale=-2:720")
    if speed != 1.0:
        vf.append(f"setpts=PTS/{speed}")
    enc = (["-c:v", "h264_videotoolbox", "-b:v", "3M"] if preview else
           ["-c:v", "h264_videotoolbox", "-b:v", "14M", "-maxrate", "20M", "-bufsize", "28M"])
    if "h264_videotoolbox" not in ENCODERS:
        enc = ["-c:v", "libx264", "-preset", "veryfast" if preview else "medium", "-crf", "28" if preview else "18"]
    nframes = fb - fa
    cmd = [FF, "-v", "error", "-y", "-ss", f"{fa / fps:.6f}", "-i", str(src), "-an",
           "-frames:v", str(nframes), "-r", f"{fps:.6f}"]
    if vf:
        cmd += ["-vf", ",".join(vf)]
    cmd += enc + ["-pix_fmt", "yuv420p", "-video_track_timescale", "90000", str(path)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-400:])


def contact_sheet(video, out_jpg, n=6):
    """Лист из n кадров для проверки глазами."""
    from PIL import Image
    info = probe(video)
    d = info["duration"]
    frames = []
    with tempfile.TemporaryDirectory() as td:
        for i in range(n):
            t = d * (i + 0.5) / n
            p = Path(td) / f"f{i}.jpg"
            subprocess.run([FF, "-v", "error", "-y", "-ss", f"{t:.3f}", "-i", str(video), "-frames:v", "1",
                            "-vf", "scale=480:-2", str(p)], capture_output=True)
            if p.exists():
                frames.append(Image.open(p).convert("RGB"))
    if not frames:
        return None
    w, h = frames[0].size
    cols = 3 if w > h else 6
    rows = math.ceil(len(frames) / cols)
    sheet = Image.new("RGB", (cols * w, rows * h), "black")
    for i, im in enumerate(frames):
        sheet.paste(im, ((i % cols) * w, (i // cols) * h))
    sheet.save(out_jpg, quality=85)
    return str(out_jpg)


def run(args):
    src = Path(args.video).expanduser()
    if not src.exists():
        die(4, f"файл не найден: {src}")
    info = probe(src)
    if not info["has_video"]:
        die(4, "в файле нет видео (для звука используй транскрибацию)")
    segs = load_plan(args, info["duration"])
    audio = load_audio(src) if info["has_audio"] else np.zeros((int(info["duration"] * SR), 2), np.float32)
    if args.tighten:
        sil_path = Path(args.silence) if args.silence else None
        if not sil_path:
            cands = [src.with_name(src.stem + "_silence.json"),
                     src.parent.parent / "расшифровка" / (src.stem + "_silence.json")]
            sil_path = next((c for c in cands if c.exists()), None)
        if not sil_path or not sil_path.exists():
            die(2, "для --tighten нужна карта тишины ИМЯ_silence.json (её делает transcribe.py) или --silence ФАЙЛ")
        segs = tighten(segs, json.load(open(sil_path, encoding="utf-8"))["silences"])
    if not args.no_snap:
        segs = snap_inward(audio, segs)
    fps = info["fps"]
    q = quantize(segs, fps)
    if not q:
        die(2, "после проверки не осталось ни одного куска длиннее 0,15 с")
    total = sum(fb - fa for fa, fb in q) / fps
    out = Path(args.out).expanduser() if args.out else default_out(src, args.preview)
    table, t_out = [], 0.0
    for fa, fb in q:
        dur = (fb - fa) / fps / args.speed
        table.append({"src_start": round(fa / fps, 3), "src_end": round(fb / fps, 3),
                      "out_start": round(t_out, 3), "out_end": round(t_out + dur, 3)})
        t_out += dur
    summary = {"source": str(src), "out": str(out), "segments": len(q),
               "source_duration": round(info["duration"], 2), "result_duration": round(total / args.speed, 2),
               "removed_sec": round(info["duration"] - total, 2), "speed": args.speed, "preview": args.preview}
    if args.dry_run:
        print(json.dumps({"ok": True, "dry_run": True, **summary, "table": table[:40]}, ensure_ascii=False, indent=1))
        return

    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        # звук: режем по сэмплам в точках кадров, на каждом стыке 8 мс затухания
        parts, nf = [], int(FADE * SR)
        ramp_in, ramp_out = np.linspace(0, 1, nf, dtype=np.float32)[:, None], np.linspace(1, 0, nf, dtype=np.float32)[:, None]
        for fa, fb in q:
            chunk = audio[int(round(fa / fps * SR)):int(round(fb / fps * SR))].copy()
            if len(chunk) > 2 * nf:
                chunk[:nf] *= ramp_in
                chunk[-nf:] *= ramp_out
            parts.append(chunk)
        joined = np.concatenate(parts)
        wav = td / "a.wav"
        raw = td / "a.f32"
        joined.astype(np.float32).tofile(raw)
        # pan явно помечает звук как стерео: у сырого f32le раскладки нет, и фильтры дальше на этом спотыкаются
        af = ["pan=stereo|c0=c0|c1=c1"] + ([f"atempo={args.speed}"] if args.speed != 1.0 else [])
        if args.normalize:
            af.append("loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,aformat=channel_layouts=stereo")   # −14 LUFS: так соцсети и YouTube выравнивают громкость сами
        cmd = [FF, "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", str(raw)]
        cmd += ["-af", ",".join(af)]
        subprocess.run(cmd + ["-ar", str(SR), str(wav)], check=True)
        print(f">> Звук собран ({len(q)} кусков), рендерю видео…", file=sys.stderr)
        seg_paths = [td / f"v{i:04d}.mp4" for i in range(len(q))]
        try:
            with ThreadPoolExecutor(max_workers=3) as ex:
                list(ex.map(lambda i: render_video_seg(src, q[i][0], q[i][1], fps, seg_paths[i], args.preview, args.speed),
                            range(len(q))))
        except RuntimeError as e:
            die(5, f"рендер куска упал: {e}")
        lst = td / "list.txt"
        lst.write_text("".join(f"file '{p}'\n" for p in seg_paths), encoding="utf-8")
        r = subprocess.run([FF, "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-i", str(wav),
                            "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                            "-movflags", "+faststart", "-shortest", str(out)], capture_output=True, text=True)
        if r.returncode != 0:
            die(5, "склейка упала: " + r.stderr[-400:])

    joins = [row["out_start"] for row in table[1:]]
    joins_path = out.with_name(out.stem + "_joins.json")
    json.dump({"source": str(src), "joins": joins, "table": table}, open(joins_path, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    summary["joins_file"] = str(joins_path)
    real = probe(out)["duration"]
    summary["check"] = {"result_duration_real": round(real, 2),
                        "duration_ok": abs(real - summary["result_duration"]) < 0.25}
    if args.sheet:
        summary["sheet"] = contact_sheet(out, out.with_name(out.stem + "_check.jpg"))
    print(json.dumps({"ok": True, **summary}, ensure_ascii=False, indent=1))


ENCODERS = ""


def main():
    global ENCODERS
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--keep")
    ap.add_argument("--remove")
    ap.add_argument("--out")
    ap.add_argument("--silence", help="путь к ИМЯ_silence.json, если лежит не рядом")
    ap.add_argument("--tighten", action="store_true")
    ap.add_argument("--no-snap", action="store_true")
    ap.add_argument("--speed", type=float, default=1.0)
    ap.add_argument("--preview", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--sheet", action="store_true")
    ap.add_argument("--normalize", action="store_true")
    args = ap.parse_args()
    if not 0.5 <= args.speed <= 2.0:
        die(2, "--speed должен быть от 0.5 до 2.0")
    ENCODERS = subprocess.run([FF, "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
    run(args)


if __name__ == "__main__":
    main()
