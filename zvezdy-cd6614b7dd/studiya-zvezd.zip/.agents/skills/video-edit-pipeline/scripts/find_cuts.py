#!/usr/bin/env python3
"""Находит, что можно вырезать: длинные паузы, мычание, перезаходы и повторы.
Ничего не режет: пишет список предложений, который человек подтверждает.

Использование:
  .agents/run video-edit-pipeline/scripts/find_cuts.py ИМЯ_words.json [опции]

Опции:
  --silence ФАЙЛ      карта тишины (по умолчанию ИМЯ_silence.json рядом)
  --min-pause 1.0     паузы дольше этого (сек) предлагаются к сокращению
  --keep-pause 0.4    сколько тишины оставить на месте вырезанной паузы
  --out ФАЙЛ          куда записать список (по умолчанию ИМЯ_cuts.json рядом)

Каждый пункт: {"id", "start", "end", "kind", "text", "apply"}.
kind: pause (пауза) · hesitation (мычание «эээ», «ммм») · restart (перезаход: фраза начата заново)
· filler (слово-паразит: только предложение, apply=false).
apply=true у пауз и мычания, apply=false у перезаходов и паразитов: их решает человек.
В stdout JSON: сводка и первые 60 пунктов. Коды: 0 готово, 4 нет файла.
"""
import argparse
import json
import re
import sys
from pathlib import Path

HESITATION = re.compile(r"^(э+|эм+|ээм+|мм+|хм+|а-а+|ам+|ммм+|uh+|um+|hmm+)$")
# Слова-паразиты: ТОЛЬКО предложение. В живой речи «ну», «смотри», «вот» часто часть голоса.
FILLERS = {"короче", "как бы", "типа", "то есть", "в общем", "значит", "вот", "ну", "слушай", "смотри"}
RESTART_WINDOW = 8.0   # повтор тех же слов в пределах 8 с почти всегда перезаход, а не приём


def norm(w):
    return re.sub(r"[^\wё-]+", "", w.lower().replace("ё", "е"))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("words")
    ap.add_argument("--silence")
    ap.add_argument("--min-pause", type=float, default=1.0)
    ap.add_argument("--keep-pause", type=float, default=0.4)
    ap.add_argument("--out")
    args = ap.parse_args()
    wp = Path(args.words)
    if not wp.exists():
        print(json.dumps({"ok": False, "error": f"нет файла {wp}"}, ensure_ascii=False))
        sys.exit(4)
    words = json.load(open(wp, encoding="utf-8"))
    sp = Path(args.silence) if args.silence else wp.with_name(wp.name.replace("_words.json", "_silence.json"))
    silences = json.load(open(sp, encoding="utf-8"))["silences"] if sp.exists() else []
    items = []

    # 1. Паузы: только из звука. Whisper прячет паузы внутрь растянутых слов, зазоры между словами врут.
    for s in silences:
        if s["dur"] >= args.min_pause:
            a, b = s["start"] + args.keep_pause / 2, s["end"] - args.keep_pause / 2
            items.append({"start": a, "end": b, "kind": "pause", "text": f"пауза {s['dur']:.1f} с", "apply": True})

    # 2. Мычание
    for w in words:
        if HESITATION.match(norm(w["word"])):
            items.append({"start": w["start"] - 0.03, "end": w["end"] + 0.03, "kind": "hesitation",
                          "text": w["word"], "apply": True})

    # 3. Перезаходы: те же 3 слова повторяются в пределах 8 с. Вырезаем первую попытку целиком.
    n, used = len(words), set()
    toks = [norm(w["word"]) for w in words]
    for i in range(n - 3):
        if i in used or not all(toks[i:i + 3]):
            continue
        for j in range(i + 1, min(n - 2, i + 30)):
            if words[j]["start"] - words[i]["start"] > RESTART_WINDOW:
                break
            if toks[j:j + 3] == toks[i:i + 3]:
                text = " ".join(w["word"] for w in words[i:j + 3])
                items.append({"start": words[i]["start"] - 0.05, "end": words[j]["start"] - 0.05, "kind": "restart",
                              "text": text, "apply": False})
                used.update(range(i, j))
                break

    # 4. Паразиты: одиночные и пары слов
    for i, w in enumerate(words):
        one = norm(w["word"])
        two = one + " " + norm(words[i + 1]["word"]) if i + 1 < n else ""
        if two in FILLERS:
            items.append({"start": w["start"], "end": words[i + 1]["end"], "kind": "filler",
                          "text": w["word"] + " " + words[i + 1]["word"], "apply": False})
        elif one in FILLERS:
            items.append({"start": w["start"], "end": w["end"], "kind": "filler", "text": w["word"], "apply": False})

    items.sort(key=lambda x: x["start"])
    for k, it in enumerate(items, 1):
        it["id"] = k
        it["start"], it["end"] = round(max(0, it["start"]), 3), round(it["end"], 3)
    out = Path(args.out) if args.out else wp.with_name(wp.name.replace("_words.json", "_cuts.json"))
    json.dump({"source_words": str(wp), "cuts": items}, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    by = {}
    for it in items:
        by.setdefault(it["kind"], [0, 0.0])
        by[it["kind"]][0] += 1
        by[it["kind"]][1] += it["end"] - it["start"]
    print(json.dumps({"ok": True, "file": str(out),
                      "summary": {k: {"count": v[0], "seconds": round(v[1], 1)} for k, v in by.items()},
                      "auto_apply_seconds": round(sum(i["end"] - i["start"] for i in items if i["apply"]), 1),
                      "items": items[:60], "more": max(0, len(items) - 60)}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
