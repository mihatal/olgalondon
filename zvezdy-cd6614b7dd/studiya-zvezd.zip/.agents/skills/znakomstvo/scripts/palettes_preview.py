#!/usr/bin/env python3
"""Нарисовать лист с готовыми стилями школы, чтобы владелица выбрала глазами.

Использование: .agents/run znakomstvo/scripts/palettes_preview.py
Создаёт Бренд/готовые стили.png (шесть карточек: фон, текст, кнопка, название стиля).
Шрифты на листе системные: настоящие шрифты стиля скачаются после выбора.
"""
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

REF = Path(__file__).resolve().parents[1] / "references" / "palettes.json"


def sysfont(size):
    for f in ("/System/Library/Fonts/Supplemental/Arial.ttf", "/Library/Fonts/Arial Unicode.ttf",
              "C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/segoeui.ttf"):
        if Path(f).exists():
            return ImageFont.truetype(f, size)
    return ImageFont.load_default(size)


def main():
    pals = {k: v for k, v in json.loads(REF.read_text(encoding="utf-8")).items() if not k.startswith("_")}
    rgb = lambda h: tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))  # noqa: E731
    cw, ch, pad = 760, 420, 40
    W, H = pad + 2 * (cw + pad), pad + 3 * (ch + pad)
    img = Image.new("RGB", (W, H), (240, 240, 240))
    d = ImageDraw.Draw(img)
    for n, (name, p) in enumerate(pals.items()):
        x, y = pad + (n % 2) * (cw + pad), pad + (n // 2) * (ch + pad)
        c = p["colors"]
        d.rounded_rectangle((x, y, x + cw, y + ch), radius=24, fill=rgb(c["bg"]))
        d.text((x + 40, y + 36), f"{n + 1}. {name}", font=sysfont(48), fill=rgb(c["text"]))
        d.text((x + 40, y + 104), p["mood"], font=sysfont(28), fill=rgb(c["muted"]))
        d.rounded_rectangle((x + 40, y + 160, x + cw - 40, y + 280), radius=18, fill=rgb(c["surface"]))
        d.text((x + 70, y + 190), "Карточка урока: текст и задания", font=sysfont(30), fill=rgb(c["text"]))
        d.text((x + 70, y + 232), f"шрифты: {p['fonts']['head'][0]} + {p['fonts']['text'][0]}", font=sysfont(24), fill=rgb(c["muted"]))
        d.rounded_rectangle((x + 40, y + 310, x + 330, y + 380), radius=35, fill=rgb(c["accent"]))
        d.text((x + 185, y + 345), "Записаться", font=sysfont(30), fill=rgb(c["accent_text"]), anchor="mm")
    studio.BRAND_DIR.mkdir(exist_ok=True)
    out = studio.BRAND_DIR / "готовые стили.png"
    img.save(out)
    print(json.dumps({"ok": True, "file": str(out.relative_to(studio.STUDIO)), "styles": list(pals)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
