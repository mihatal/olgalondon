#!/usr/bin/env python3
"""Применить фирстиль школы ко всем навыкам Студии.

Использование:
  .agents/run znakomstvo/scripts/apply_brand.py            проверить Бренд/brand.json и разложить стиль
  .agents/run znakomstvo/scripts/apply_brand.py --check    только проверить, ничего не писать

Что делает:
  1. Проверяет brand.json: все поля, цвета, шрифты на диске, контраст текста и кнопок.
  2. Пишет Бренд/brand.css: цвета и шрифты для сайтов, интерактивов и превью презентаций.
  3. Пишет стиль рилзов .agents/skills/reels-workflow/assets/style.json из цветов школы.
  4. Пишет Бренд/BRAND.md: понятная выжимка для человека и для текстов.
  5. Рисует Бренд/образец стиля.png: карточку, по которой владелица подтверждает стиль.
Коды: 0 готово, 3 нет шрифта, 6 нет brand.json, 9 ошибки в brand.json (список в выводе).
"""
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

COLOR_ROLES = {
    "bg": "фон страниц и слайдов",
    "surface": "фон карточек и плашек",
    "text": "основной текст на фоне",
    "muted": "второстепенный текст",
    "accent": "акцент: кнопки, выделения, цифры",
    "accent_text": "текст на акцентной кнопке",
    "dark": "тёмный цвет для рилзов во весь кадр и подложек",
}
HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")


def lum(h):
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4  # noqa: E731
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def validate(b):
    errs, warns = [], []
    for k in ("school", "colors", "fonts", "voice"):
        if k not in b:
            errs.append(f"нет поля {k}")
    if errs:
        return errs, warns
    c = b["colors"]
    for role, why in COLOR_ROLES.items():
        if not HEX.match(str(c.get(role, ""))):
            errs.append(f"colors.{role} ({why}) должен быть цветом вида #12AB34")
    if not errs:
        for fg, bg, need, what in (("text", "bg", 4.5, "текст на фоне"), ("accent_text", "accent", 4.5, "текст на кнопке"),
                                   ("text", "surface", 4.5, "текст на карточке"), ("muted", "bg", 3.0, "второстепенный текст")):
            r = contrast(c[fg], c[bg])
            if r < need:
                errs.append(f"{what} читается плохо: контраст {r:.1f}, нужно от {need}. Поменяй colors.{fg} или colors.{bg}")
        if contrast(c["accent"], c["bg"]) < 1.8:
            warns.append("акцент почти сливается с фоном: кнопки будут незаметны")
        if contrast(c["dark"], "#FFFFFF") < 7:
            warns.append("colors.dark недостаточно тёмный: белые субтитры на нём будут хуже читаться")
    for role in ("head", "text"):
        f = b["fonts"].get(role)
        if not f or not f.get("file"):
            errs.append(f"fonts.{role}: нужен файл шрифта (get_font.py)")
        elif not (studio.STUDIO / f["file"]).exists():
            errs.append(f"fonts.{role}: файла {f['file']} нет на диске")
    v = b["voice"]
    if v.get("address") not in ("ты", "вы"):
        errs.append("voice.address: «ты» или «вы»")
    for p in [b.get("logo")] + list(b.get("photos") or []):
        if p and not (studio.STUDIO / p).exists():
            warns.append(f"файла {p} нет на диске")
    return errs, warns


def write_css(b):
    c, f = b["colors"], b["fonts"]
    faces = []
    seen = set()
    for role in ("head", "text", "text_bold"):
        if role not in f or f[role]["file"] in seen:
            continue
        seen.add(f[role]["file"])
        rel = Path(f[role]["file"]).relative_to("Бренд").as_posix()
        faces.append(f"@font-face{{font-family:'{f[role]['family']}';src:url('{rel}');"
                     f"font-weight:{f[role].get('weight', 400)};font-display:swap}}")
    vars_ = "\n".join(f"  --{k.replace('_', '-')}:{v};" for k, v in c.items())
    css = (f"/* Фирстиль школы «{b['school']}». Собирается из brand.json скриптом apply_brand.py: правь brand.json, не этот файл. */\n"
           + "\n".join(faces) + "\n:root{\n" + vars_ +
           f"\n  --font-head:'{f['head']['family']}',system-ui,sans-serif;\n  --font-text:'{f['text']['family']}',system-ui,sans-serif;"
           f"\n  --head-weight:{f['head'].get('weight', 700)};\n  --radius:{b.get('radius', 14)}px;\n}}\n")
    (studio.BRAND_DIR / "brand.css").write_text(css, encoding="utf-8")


def write_reels_style(b):
    c, f = b["colors"], b["fonts"]
    path = studio.AGENTS / "skills" / "reels-workflow" / "assets" / "style.json"
    style = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    style.update({
        "_о_файле": f"Стиль рилзов школы «{b['school']}». Собран из Бренд/brand.json (apply_brand.py). Меняй brand.json и запускай apply_brand.py.",
        "canvas": [1080, 1920], "fps": 30,
        "colors": {"bg": c["bg"], "text": c["text"], "accent": c["accent"], "on_accent": c["accent_text"],
                   "dark": c["dark"], "light": "#FFFFFF"},
        "fonts": {"head": f["head"]["file"], "mark": f.get("text_bold", f["text"])["file"]},
        "font_axes": {},
    })
    lay = style.setdefault("layouts", {})
    lay["split"] = {"_": "видео сверху 1080×960, ниже фон школы: хук, субтитры, призыв. Правый край текста ≤ 930 px",
                    "video_box": [0, 0, 1080, 960], "background": "bg",
                    "hook": {"y": 1112, "max_w": 900, "fs_max": 100, "fs_min": 56, "lines": 3, "color": "text", "underline": "accent"},
                    "subs": {"y": 1405, "max_w": 780, "fs_max": 112, "fs_min": 60, "lines": 1, "color": "text", "active": "accent", "stroke": None},
                    "cta": {"y": 1590, "max_w": 760, "fs": 66, "color": "accent", "rotate": -3, "stroke": None}}
    lay["full"] = {"_": "видео на весь кадр 9:16, хук на акцентной плашке сверху, субтитры с тёмной обводкой",
                   "video_box": [0, 0, 1080, 1920], "background": "dark",
                   "hook": {"y": 340, "max_w": 900, "fs_max": 92, "fs_min": 52, "lines": 3, "color": "on_accent", "plate": "accent"},
                   "subs": {"y": 1270, "max_w": 780, "fs_max": 108, "fs_min": 60, "lines": 1, "color": "light", "active": "accent", "stroke": "dark"},
                   "cta": {"y": 1480, "max_w": 760, "fs": 64, "color": "accent", "rotate": -3, "stroke": "dark"}}
    style.setdefault("subs", {"max_words": 3, "max_chars": 18, "break_gap": 0.35, "hold_after": 0.6})
    style.setdefault("hook_time", {"min": 5, "max": 12, "share": 0.25})
    style.setdefault("cta_from", 20)
    style.setdefault("video_bitrate", "12M")
    style.setdefault("speed", 1.1)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(style, ensure_ascii=False, indent=1), encoding="utf-8")


def write_md(b):
    c, f, v = b["colors"], b["fonts"], b["voice"]
    lines = [f"# Фирстиль школы «{b['school']}»", "",
             "Источник правды: brand.json рядом. Этот файл собирается из него автоматически (apply_brand.py), правь brand.json.", "",
             "## Кто мы", f"- Школа: {b['school']}", f"- Чему учим: {b.get('niche', '')}", f"- Для кого: {b.get('audience', '')}",
             f"- Город и формат: {b.get('city', '')}", "",
             "## Как говорим", f"- Обращение: на «{v['address']}»", f"- Эмодзи: {v.get('emoji', 'редко')}",
             f"- Тон: {v.get('tone', '')}", f"- Стоп-слова: {', '.join(v.get('stop_words', [])) or 'нет'}", "",
             "## Цвета"] + [f"- {COLOR_ROLES[k]}: {c[k]}" for k in COLOR_ROLES] + [
             "", "## Шрифты", f"- Заголовки: {f['head']['family']} ({f['head'].get('weight', 700)})",
             f"- Текст: {f['text']['family']}", "", "## Контакты"] + [f"- {k}: {val}" for k, val in (b.get("contacts") or {}).items() if val]
    (studio.BRAND_DIR / "BRAND.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def draw_sample(b):
    from PIL import Image, ImageDraw, ImageFont
    c = b["colors"]
    rgb = lambda h: tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))  # noqa: E731
    W, H = 1600, 900
    img = Image.new("RGB", (W, H), rgb(c["bg"]))
    d = ImageDraw.Draw(img)
    fh = lambda s: ImageFont.truetype(str(studio.font_path(b, "head")), s)  # noqa: E731
    ft = lambda s: ImageFont.truetype(str(studio.font_path(b, "text")), s)  # noqa: E731
    d.text((100, 110), b["school"].upper(), font=fh(96), fill=rgb(c["text"]))
    d.text((100, 250), b.get("niche", "Чему учим"), font=ft(44), fill=rgb(c["muted"]))
    d.rounded_rectangle((100, 360, 900, 700), radius=28, fill=rgb(c["surface"]))
    d.text((150, 410), "Карточка урока", font=fh(54), fill=rgb(c["text"]))
    d.text((150, 500), "Так выглядит текст в карточках,\nзаданиях и на сайте.", font=ft(38), fill=rgb(c["text"]), spacing=12)
    d.rounded_rectangle((100, 750, 560, 840), radius=45, fill=rgb(c["accent"]))
    d.text((330, 795), "Записаться", font=fh(42), fill=rgb(c["accent_text"]), anchor="mm")
    x = 950
    for k in COLOR_ROLES:
        d.rounded_rectangle((x, 120 + list(COLOR_ROLES).index(k) * 100, x + 80, 200 + list(COLOR_ROLES).index(k) * 100),
                            radius=16, fill=rgb(c[k]), outline=rgb(c["muted"]), width=2)
        d.text((x + 110, 160 + list(COLOR_ROLES).index(k) * 100), COLOR_ROLES[k], font=ft(25), fill=rgb(c["text"]), anchor="lm")
    logo = b.get("logo")
    if logo and (studio.STUDIO / logo).exists():
        lg = Image.open(studio.STUDIO / logo).convert("RGBA")
        lg.thumbnail((220, 220))
        img.paste(lg, (W - lg.width - 60, H - lg.height - 50), lg)
    out = studio.BRAND_DIR / "образец стиля.png"
    img.save(out)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if not studio.BRAND_JSON.exists():
        studio.die(6, "нет Бренд/brand.json. Его пишет Codex по итогам знакомства (шаблон: references/brand.example.json)")
    b = json.loads(studio.BRAND_JSON.read_text(encoding="utf-8"))
    errs, warns = validate(b)
    if errs:
        print(json.dumps({"ok": False, "errors": errs, "warnings": warns}, ensure_ascii=False, indent=1))
        sys.exit(9)
    if a.check:
        print(json.dumps({"ok": True, "warnings": warns}, ensure_ascii=False, indent=1))
        return
    write_css(b)
    write_reels_style(b)
    write_md(b)
    sample = draw_sample(b)
    print(json.dumps({"ok": True, "warnings": warns, "written": [
        "Бренд/brand.css", "Бренд/BRAND.md", str(sample.relative_to(studio.STUDIO)),
        ".agents/skills/reels-workflow/assets/style.json"]}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
