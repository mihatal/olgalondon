#!/usr/bin/env python3
"""Поставить шрифты школы в систему, чтобы PowerPoint и Keynote показывали презентации правильно.

Использование: .agents/run znakomstvo/scripts/install_fonts.py
Mac: копирует в ~/Library/Fonts. Windows: в папку шрифтов пользователя и реестр (без прав администратора).
Пишет за пределы папки Студии, поэтому Codex попросит разрешение: это ожидаемо.
"""
import json
import os
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402


def main():
    files = sorted(p for p in (studio.BRAND_DIR / "fonts").glob("*") if p.suffix.lower() in (".ttf", ".otf"))
    if not files:
        studio.die(4, "в Бренд/fonts нет шрифтов. Сначала get_font.py")
    done = []
    if studio.IS_WIN:
        import winreg
        dst_dir = Path(os.environ["LOCALAPPDATA"]) / "Microsoft" / "Windows" / "Fonts"
        dst_dir.mkdir(parents=True, exist_ok=True)
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows NT\CurrentVersion\Fonts")
        from fontTools.ttLib import TTFont
        for f in files:
            dst = dst_dir / f.name
            shutil.copy2(f, dst)
            nm = TTFont(str(f))["name"].getDebugName(4) or f.stem
            winreg.SetValueEx(key, f"{nm} (TrueType)", 0, winreg.REG_SZ, str(dst))
            done.append(str(dst))
    else:
        dst_dir = Path.home() / "Library" / "Fonts"
        dst_dir.mkdir(parents=True, exist_ok=True)
        for f in files:
            shutil.copy2(f, dst_dir / f.name)
            done.append(str(dst_dir / f.name))
    print(json.dumps({"ok": True, "installed": done,
                      "note": "Если PowerPoint или Keynote были открыты, перезапусти их"}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
