#!/usr/bin/env python3
"""Скачать шрифт с Google Fonts в Бренд/fonts и проверить, что в нём есть русские буквы.

Использование:
  .agents/run znakomstvo/scripts/get_font.py "Manrope" --weights 400,700
  .agents/run znakomstvo/scripts/get_font.py --file "C:/путь/МойШрифт.ttf"   свой файл школы

Печатает JSON: для каждого начертания файл, вес и имя для PowerPoint/Keynote (pptx_name).
Коды: 0 готово, 2 ошибка аргументов, 4 шрифт не найден, 7 нет кириллицы, 8 нет интернета.
"""
import argparse
import json
import re
import shutil
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

FONTS = studio.BRAND_DIR / "fonts"


def info(path):
    from fontTools.ttLib import TTFont
    f = TTFont(str(path))
    cmap = f.getBestCmap() or {}
    cyr = all(ord(c) in cmap for c in "АБВЖЩЯабвжщяЁё")
    name = f["name"]
    fam = name.getDebugName(1) or path.stem
    typo = name.getDebugName(16) or fam
    w = f["OS/2"].usWeightClass if "OS/2" in f else 400
    return {"cyrillic": cyr, "pptx_name": fam, "family": typo, "weight": w}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("family", nargs="?")
    ap.add_argument("--weights", default="400,700")
    ap.add_argument("--file", help="свой файл шрифта .ttf/.otf")
    a = ap.parse_args()
    FONTS.mkdir(parents=True, exist_ok=True)
    out = []
    if a.file:
        src = Path(a.file).expanduser()
        if not src.exists():
            studio.die(4, f"файл не найден: {src}")
        dst = FONTS / src.name
        shutil.copy2(src, dst)
        i = info(dst)
        out.append({"file": str(dst.relative_to(studio.STUDIO)).replace("\\", "/"), **i})
    else:
        if not a.family:
            studio.die(2, "укажи название шрифта, например \"Manrope\"")
        ws = [w.strip() for w in a.weights.split(",") if w.strip()]
        fam = a.family.strip()
        url = ("https://fonts.googleapis.com/css2?family=" + fam.replace(" ", "+") +
               ":wght@" + ";".join(ws))
        try:
            css = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Python-urllib/3"}),
                                         timeout=30).read().decode()
        except urllib.error.HTTPError as e:
            if e.code == 400:
                studio.die(4, f"на Google Fonts нет шрифта «{fam}» с весами {a.weights}. Проверь название на fonts.google.com")
            studio.die(8, f"Google Fonts ответил ошибкой {e.code}")
        except Exception as e:  # noqa: BLE001
            studio.die(8, f"нет доступа к Google Fonts: {e}. Включи VPN или дай Codex доступ в интернет")
        faces = re.findall(r"font-weight:\s*(\d+);.*?src:\s*url\((https://[^)]+\.ttf)\)", css, re.S)
        if not faces:
            studio.die(4, f"Google Fonts не отдал файлы для «{fam}»")
        for w, link in faces:
            dst = FONTS / f"{fam.replace(' ', '')}-{w}.ttf"
            with urllib.request.urlopen(link, timeout=60) as r, open(dst, "wb") as f:
                f.write(r.read())
            out.append({"file": str(dst.relative_to(studio.STUDIO)).replace("\\", "/"), **info(dst)})
    bad = [o for o in out if not o["cyrillic"]]
    print(json.dumps({"ok": not bad, "fonts": out}, ensure_ascii=False, indent=1))
    for o in bad:
        (studio.STUDIO / o["file"]).unlink(missing_ok=True)
    if bad:
        print("ОШИБКА: в шрифте нет русских букв, выбери другой", file=sys.stderr)
        sys.exit(7)


if __name__ == "__main__":
    main()
