#!/usr/bin/env python3
"""Достать основные цвета из логотипа, скриншота сайта или фото школы.

Использование: .agents/run znakomstvo/scripts/colors_from_image.py "Бренд/logo.png" [--n 6]
Печатает JSON: цвета по убыванию доли, без почти белых и почти чёрных фоновых пикселей отдельно отмечает.
По ним Codex предлагает роли (фон, текст, акцент) и проверяет контраст через apply_brand.py --check.
"""
import argparse
import json
import sys
from pathlib import Path

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("image")
    ap.add_argument("--n", type=int, default=6)
    a = ap.parse_args()
    p = Path(a.image)
    if not p.is_absolute():
        p = studio.STUDIO / p
    if not p.exists():
        studio.die(4, f"нет файла {p}")
    im = Image.open(p).convert("RGBA")
    im.thumbnail((300, 300))
    px = [(r, g, b) for r, g, b, al in im.getdata() if al > 200]
    if not px:
        studio.die(4, "в картинке нет непрозрачных пикселей")
    q = Image.new("RGB", (len(px), 1))
    q.putdata(px)
    q = q.quantize(colors=max(2, a.n + 2), method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette()
    counts = sorted(q.getcolors(), reverse=True)
    total = sum(c for c, _ in counts)
    out = []
    for c, i in counts:
        r, g, b = pal[i * 3:i * 3 + 3]
        hx = f"#{r:02X}{g:02X}{b:02X}"
        light = (r + g + b) / 3
        out.append({"hex": hx, "share": round(c / total, 3),
                    "kind": "почти белый" if light > 240 else "почти чёрный" if light < 20 else "цвет"})
    print(json.dumps({"ok": True, "image": str(p), "colors": out[:a.n + 2]}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
