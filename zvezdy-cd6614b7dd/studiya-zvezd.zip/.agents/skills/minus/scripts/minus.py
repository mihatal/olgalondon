#!/usr/bin/env python3
"""Минусовка из песни: убрать голос, оставить музыку; по желанию сдвинуть тональность под ученика.

Использование:
  .agents/run minus/scripts/minus.py "Музыка/исходник/песня.mp3"                   минус и отдельный голос
  .agents/run minus/scripts/minus.py "Музыка/исходник/песня.mp3" --shift -2        ещё и на 2 полутона ниже
  .agents/run minus/scripts/minus.py --install                                     поставить движок (один раз, около 1 ГБ)

Создаёт в папке «готово» рядом с исходником (или в Музыка/готово):
  <имя> — минус.mp3, <имя> — голос.mp3, с --shift ещё <имя> — минус (−2).mp3
Модель Demucs (htdemucs) работает на компьютере, песня никуда не отправляется. Минута песни ≈ 20–60 секунд работы.
Коды: 0 готово, 2 ошибка аргументов, 3 нет ffmpeg, 4 нет файла, 5 разделение упало, 10 движок не установлен.
"""
import argparse
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402


def install():
    uv = studio.tool("uv")
    py = studio.AGENTS / ".venv" / ("Scripts/python.exe" if studio.IS_WIN else "bin/python")
    req = studio.AGENTS / "requirements-minus.txt"
    r = subprocess.run([uv, "pip", "install", "--python", str(py), "-r", str(req)])
    if r.returncode != 0:
        studio.die(5, "движок минусовок не поставился, текст ошибки выше")
    print(json.dumps({"ok": True, "installed": "demucs"}, ensure_ascii=False))


def shift_pitch(ff, src, dst, semis):
    ratio = 2 ** (semis / 12)
    # без изменения темпа: меняем частоту дискретизации и компенсируем темп
    tempo = 1 / ratio
    chain = []
    while tempo < 0.5 or tempo > 2.0:
        step = 0.5 if tempo < 0.5 else 2.0
        chain.append(f"atempo={step}")
        tempo /= step
    chain.append(f"atempo={tempo:.6f}")
    af = f"asetrate=44100*{ratio:.6f},aresample=44100," + ",".join(chain)
    subprocess.run([ff, "-v", "error", "-y", "-i", str(src), "-af", af, "-b:a", "256k", str(dst)], check=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("song", nargs="?")
    ap.add_argument("--shift", type=int, default=0, help="сдвиг тональности в полутонах, от -6 до 6")
    ap.add_argument("--install", action="store_true")
    a = ap.parse_args()
    if a.install:
        return install()
    if importlib.util.find_spec("demucs") is None:
        studio.die(10, "движок минусовок не установлен. Запусти minus.py --install (один раз, около 1 ГБ)")
    if not a.song:
        studio.die(2, "укажи файл песни")
    if abs(a.shift) > 6:
        studio.die(2, "сдвиг больше 6 полутонов звучит плохо, выбери от -6 до 6")
    ff = studio.tool("ffmpeg")
    src = Path(a.song)
    if not src.is_absolute():
        src = Path.cwd() / src
    if not src.exists():
        studio.die(4, f"нет файла {src}")
    out_dir = src.parent.parent / "готово" if src.parent.name.lower() == "исходник" else src.parent / "готово"
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = src.stem
    with tempfile.TemporaryDirectory() as td:
        wav = Path(td) / "in.wav"
        subprocess.run([ff, "-v", "error", "-y", "-i", str(src), "-ac", "2", "-ar", "44100", str(wav)], check=True)
        print(">> Отделяю голос от музыки (минута песни ≈ 20–60 секунд)", file=sys.stderr)
        r = subprocess.run([sys.executable, "-m", "demucs", "--two-stems", "vocals", "-n", "htdemucs", "-o", td, str(wav)])
        if r.returncode != 0:
            studio.die(5, "разделение упало, текст ошибки выше")
        sep = Path(td) / "htdemucs" / "in"
        minus = out_dir / f"{stem} — минус.mp3"
        voice = out_dir / f"{stem} — голос.mp3"
        for s, d in ((sep / "no_vocals.wav", minus), (sep / "vocals.wav", voice)):
            subprocess.run([ff, "-v", "error", "-y", "-i", str(s), "-b:a", "256k", str(d)], check=True)
        res = {"ok": True, "minus": str(minus), "voice": str(voice)}
        if a.shift:
            sh = out_dir / f"{stem} — минус ({a.shift:+d}).mp3"
            shift_pitch(ff, sep / "no_vocals.wav", sh, a.shift)
            res["minus_shifted"] = str(sh)
    print(json.dumps(res, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
