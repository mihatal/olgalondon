#!/usr/bin/env python3
"""Собрать интерактив к уроку из шаблона в фирстиле школы: папка, которую можно открыть или опубликовать.

Использование:
  .agents/run lesson-interactive/scripts/make_interactive.py cards "Уроки/2026-11-20 Слова Food/data.json"
  ... --out "Уроки/2026-11-20 Слова Food/сайт"   (по умолчанию папка «сайт» рядом с data.json)
  ... --index                                    разрешить поисковикам (по умолчанию страница скрыта от поиска)
  .agents/run lesson-interactive/scripts/make_interactive.py --list   какие шаблоны есть

Шаблоны: cards (карточки с озвучкой), quiz (викторина или раскладка по группам), gapfill (текст с пропусками,
можно с аудио), tuner (тюнер и распевка по микрофону), ear (интервалы и аккорды на слух).
Свой интерактив без шаблона: --template-file путь/к/своему.html (с теми же метками /*__DATA__*/ и /*__BRAND__*/).

Создаёт в папке: index.html, brand.css, ui.css, shell.js, fonts/ и файлы, на которые ссылается data.json
(поля audio, image, photo, src). Коды: 0 готово, 2 ошибка аргументов или data.json, 6 нет фирстиля.
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

ASSETS = Path(__file__).resolve().parents[1] / "assets"
TEMPLATES = {"cards": "карточки с переворотом и озвучкой", "quiz": "викторина с вариантами или раскладка по группам",
             "gapfill": "текст с пропусками, можно с песней или записью", "tuner": "тюнер и распевка по микрофону",
             "ear": "интервалы и аккорды на слух"}
ROBOTS = '<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex">'
FILE_KEYS = ("audio", "image", "photo", "src", "img")


def safe_json(obj):
    return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")


def collect_files(obj, found):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in FILE_KEYS and isinstance(v, str) and not v.startswith(("http://", "https://", "data:")):
                found.add(v)
            else:
                collect_files(v, found)
    elif isinstance(obj, list):
        for v in obj:
            collect_files(v, found)


def build(template_html, data, data_dir, out, brand, index):
    out.mkdir(parents=True, exist_ok=True)
    (out / "fonts").mkdir(exist_ok=True)
    shutil.copy2(studio.BRAND_DIR / "brand.css", out / "brand.css")
    for f in (studio.BRAND_DIR / "fonts").glob("*"):
        if f.suffix.lower() in (".ttf", ".otf", ".woff", ".woff2"):
            shutil.copy2(f, out / "fonts" / f.name)
    shutil.copy2(ASSETS / "ui.css", out / "ui.css")
    shutil.copy2(ASSETS / "shell.js", out / "shell.js")
    files, missing = set(), []
    collect_files(data, files)
    for rel in files:
        src = next((p for p in (data_dir / rel, studio.STUDIO / rel) if p.exists()), None)
        if not src:
            missing.append(rel)
            continue
        dst = out / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.resolve() != dst.resolve():
            shutil.copy2(src, dst)
    pub_brand = {"school": brand["school"], "contacts": brand.get("contacts") or {}, "address": brand.get("voice", {}).get("address", "ты")}
    html = (template_html.replace("/*__DATA__*/", safe_json(studio.typo_deep(data)))
            .replace("/*__BRAND__*/", safe_json(pub_brand))
            .replace("<!--ROBOTS-->", "" if index else ROBOTS))
    (out / "index.html").write_text(html, encoding="utf-8")
    return missing


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("template", nargs="?")
    ap.add_argument("data", nargs="?")
    ap.add_argument("--out")
    ap.add_argument("--index", action="store_true")
    ap.add_argument("--template-file")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        print(json.dumps(TEMPLATES, ensure_ascii=False, indent=1))
        return
    if not a.data or not (a.template or a.template_file):
        studio.die(2, "нужно: шаблон и data.json. Список шаблонов: --list")
    brand = studio.load_brand()
    if not (studio.BRAND_DIR / "brand.css").exists():
        studio.die(6, "нет Бренд/brand.css. Запусти znakomstvo/scripts/apply_brand.py")
    if a.template_file:
        tpl = Path(a.template_file)
    else:
        if a.template not in TEMPLATES:
            studio.die(2, f"нет шаблона «{a.template}». Есть: {', '.join(TEMPLATES)}")
        tpl = ASSETS / f"{a.template}.html"
    dp = Path(a.data)
    try:
        data = json.loads(dp.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        studio.die(2, f"не читается {dp}: {e}")
    out = Path(a.out) if a.out else dp.parent / "сайт"
    missing = build(tpl.read_text(encoding="utf-8"), data, dp.parent, out, brand, a.index)
    print(json.dumps({"ok": True, "folder": str(out), "open": str(out / "index.html"),
                      "missing_files": missing, "hidden_from_search": not a.index}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
