#!/usr/bin/env python3
"""Опубликовать папку (сайт, интерактив) на GitHub Pages и получить ссылку вида https://ЛОГИН.github.io/ИМЯ/.

Использование:
  .agents/run publish/scripts/publish.py --check                                проверить вход в GitHub
  .agents/run publish/scripts/publish.py "Уроки/2026-11-20 Еда/сайт" --name eda-cards
  ... --noindex      закрыть от поисковиков (по умолчанию для уроков так и надо, для сайта школы не надо)

Повторная публикация под тем же --name обновляет ту же ссылку. Имя: латиница, цифры, дефис.
Коды: 0 опубликовано, 2 ошибка аргументов, 3 нет git или gh, 11 нет входа в GitHub, 12 GitHub отказал, 13 ссылка не открылась за 4 минуты.
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

TR = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
              ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "f",
               "h", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]))


def slug(s):
    s = "".join(TR.get(ch, ch) for ch in s.lower())
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s[:60] or "page"


def run(cmd, cwd=None, check=True):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if check and r.returncode != 0:
        studio.die(12, f"{' '.join(cmd[:3])}…: {(r.stderr or r.stdout).strip()[-400:]}")
    return r


def login(gh):
    r = run([gh, "auth", "status"], check=False)
    if r.returncode != 0:
        msg = ("Нет входа в GitHub. Открой " + ("PowerShell" if studio.IS_WIN else "Терминал") +
               ", вставь команду и следуй подсказкам (выбрать GitHub.com, войти через браузер, ввести код):\n"
               "  gh auth login --web --git-protocol https -h github.com\n"
               "Потом вернись в Codex и напиши «опубликуй ещё раз».")
        print(json.dumps({"ok": False, "error": "нет входа в GitHub", "how": msg}, ensure_ascii=False, indent=1))
        sys.exit(11)
    return run([gh, "api", "user", "-q", ".login"]).stdout.strip()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder", nargs="?")
    ap.add_argument("--name")
    ap.add_argument("--noindex", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    gh, git = studio.tool("gh"), studio.tool("git")
    user = login(gh)
    if a.check:
        print(json.dumps({"ok": True, "github_user": user}, ensure_ascii=False))
        return
    if not a.folder:
        studio.die(2, "укажи папку для публикации")
    src = Path(a.folder)
    if not (src / "index.html").exists():
        studio.die(2, f"в папке {src} нет index.html: публиковать нечего")
    name = slug(a.name or (src.parent.name if src.name == "сайт" else src.name))
    repo = f"{user}/{name}"
    run([gh, "auth", "setup-git"], check=False)

    if run([gh, "repo", "view", repo, "--json", "name"], check=False).returncode != 0:
        run([gh, "repo", "create", repo, "--public", "--disable-issues", "--disable-wiki"])
        created = True
    else:
        created = False

    work = studio.AGENTS / ".cache" / "publish" / name
    if work.exists():
        shutil.rmtree(work)
    work.parent.mkdir(parents=True, exist_ok=True)
    r = run([git, "clone", "--depth", "1", f"https://github.com/{repo}.git", str(work)], check=False)
    if r.returncode != 0 or not (work / ".git").exists():
        work.mkdir(parents=True, exist_ok=True)
        run([git, "init", "-b", "main"], cwd=work)
        run([git, "remote", "add", "origin", f"https://github.com/{repo}.git"], cwd=work)
    for p in work.iterdir():
        if p.name != ".git":
            shutil.rmtree(p) if p.is_dir() else p.unlink()
    for p in src.iterdir():
        if p.name.startswith(".") or p.name in ("data.json", "site.json", "deck.json"):
            continue
        (shutil.copytree if p.is_dir() else shutil.copy2)(p, work / p.name)
    (work / ".nojekyll").write_text("", encoding="utf-8")
    if a.noindex:
        (work / "robots.txt").write_text("User-agent: *\nDisallow: /\n", encoding="utf-8")
    run([git, "config", "user.name", user], cwd=work)
    run([git, "config", "user.email", f"{user}@users.noreply.github.com"], cwd=work)
    run([git, "add", "-A"], cwd=work)
    if run([git, "diff", "--cached", "--quiet"], cwd=work, check=False).returncode != 0:
        run([git, "commit", "-m", "Обновление страницы"], cwd=work)
        run([git, "branch", "-M", "main"], cwd=work)
        run([git, "push", "-u", "origin", "main"], cwd=work)

    pg = run([gh, "api", f"repos/{repo}/pages"], check=False)
    if pg.returncode != 0:
        run([gh, "api", "-X", "POST", f"repos/{repo}/pages", "-f", "source[branch]=main", "-f", "source[path]=/"], check=False)
    url = f"https://{user.lower()}.github.io/{name}/"
    deadline = time.time() + 240
    status = None
    while time.time() < deadline:
        try:
            status = urllib.request.urlopen(urllib.request.Request(url + f"?t={int(time.time())}"), timeout=15).status
            if status == 200:
                break
        except Exception as e:  # noqa: BLE001
            status = getattr(e, "code", str(e))
        time.sleep(10)
    ok = status == 200
    print(json.dumps({"ok": ok, "url": url, "repo": f"https://github.com/{repo}", "new_repo": created,
                      "hidden_from_search": a.noindex, "last_status": status,
                      "next": "Открой ссылку с телефона на мобильном интернете без VPN и убедись, что она открывается, прежде чем слать ученикам."},
                     ensure_ascii=False, indent=1))
    sys.exit(0 if ok else 13)


if __name__ == "__main__":
    main()
