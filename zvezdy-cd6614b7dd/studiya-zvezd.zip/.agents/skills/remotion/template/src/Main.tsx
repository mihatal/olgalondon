// Анимированный ролик из сцен в фирстиле школы. Сцены и формат задаются в scenes.json (см. SKILL.md).
import React from 'react';
import {AbsoluteFill, Sequence, Img, OffthreadVideo, Audio, staticFile, useCurrentFrame, useVideoConfig,
  spring, interpolate, CalculateMetadataFunction, continueRender, delayRender} from 'remotion';
import {loadFont} from '@remotion/fonts';
import brand from '../public/brand.json';

type Scene = {type: 'title' | 'text' | 'list' | 'big' | 'quote' | 'photo' | 'video' | 'cta';
  title?: string; text?: string; items?: string[]; author?: string; src?: string; seconds?: number; tone?: 'base' | 'accent' | 'dark' | 'surface'};
type Props = {format?: 'vertical' | 'horizontal' | 'square'; music?: string; scenes: Scene[]};

export const defaultProps: Props = {format: 'vertical', scenes: [
  {type: 'title', title: 'Заголовок ролика', text: 'подзаголовок'},
  {type: 'list', title: 'Три шага', items: ['Первый', 'Второй', 'Третий']},
  {type: 'cta', title: 'Запишись на пробный урок', text: 'Ссылка в профиле'}]};

const FPS = 30;
const dur = (s: Scene) => Math.round((s.seconds ?? (s.type === 'list' ? 5 : s.type === 'video' ? 8 : 3.5)) * FPS);
const SIZES = {vertical: [1080, 1920], horizontal: [1920, 1080], square: [1080, 1080]} as const;

export const calcMeta: CalculateMetadataFunction<Props> = ({props}) => {
  const [width, height] = SIZES[props.format ?? 'vertical'];
  return {durationInFrames: Math.max(1, props.scenes.reduce((a, s) => a + dur(s), 0)), width, height, fps: FPS};
};

const c = (brand as any).colors;
const fontFiles = (brand as any).fonts;
const fileOf = (role: string) => (fontFiles[role]?.file ?? '').split('/').pop();
const handle = delayRender('fonts');
Promise.all(['head', 'text'].map((r) => fileOf(r) ? loadFont({family: 'S-' + r, url: staticFile('fonts/' + fileOf(r))}) : null))
  .then(() => continueRender(handle)).catch(() => continueRender(handle));

const tones: Record<string, [string, string, string]> = {
  base: [c.bg, c.text, c.accent], surface: [c.surface, c.text, c.accent],
  accent: [c.accent, c.accent_text, c.accent_text], dark: [c.dark, '#FFFFFF', c.accent]};

const useIn = (delay = 0) => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig();
  const p = spring({frame: f - delay, fps, config: {damping: 200}});
  return {opacity: p, transform: `translateY(${interpolate(p, [0, 1], [40, 0])}px)`};
};

const SceneView: React.FC<{s: Scene}> = ({s}) => {
  const {width} = useVideoConfig(); const u = width / 1080;
  const tone = s.tone ?? ({big: 'accent', cta: 'dark', quote: 'surface'} as any)[s.type] ?? 'base';
  const [bg, fg, acc] = tones[tone];
  const head: React.CSSProperties = {fontFamily: 'S-head', color: fg, lineHeight: 1.05, margin: 0};
  const body: React.CSSProperties = {fontFamily: 'S-text', color: fg, lineHeight: 1.3, margin: 0};
  const pad = 96 * u;
  const a0 = useIn(0), a1 = useIn(8), a2 = useIn(16);
  const wrap: React.CSSProperties = {backgroundColor: bg, padding: pad, justifyContent: 'center'};
  if (s.type === 'photo' || s.type === 'video') return (
    <AbsoluteFill style={{backgroundColor: bg}}>
      {s.type === 'photo' ? <Img src={staticFile(s.src!)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
        : <OffthreadVideo src={staticFile(s.src!)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />}
      {s.title && <div style={{position: 'absolute', left: pad, right: pad, bottom: pad, ...a1}}>
        <h1 style={{...head, color: '#fff', fontSize: 84 * u, textShadow: '0 4px 24px rgba(0,0,0,.5)'}}>{s.title}</h1></div>}
    </AbsoluteFill>);
  return (
    <AbsoluteFill style={wrap}>
      {s.type === 'title' && <><div style={{width: 120 * u, height: 12 * u, background: acc, marginBottom: 48 * u, ...a0}} />
        <h1 style={{...head, fontSize: 120 * u, ...a1}}>{s.title}</h1>
        {s.text && <p style={{...body, fontSize: 60 * u, opacity: .8, marginTop: 40 * u, ...a2}}>{s.text}</p>}</>}
      {s.type === 'text' && <><h1 style={{...head, fontSize: 88 * u, ...a0}}>{s.title}</h1>
        <p style={{...body, fontSize: 64 * u, marginTop: 48 * u, ...a1}}>{s.text}</p></>}
      {s.type === 'big' && <h1 style={{...head, fontSize: 130 * u, textAlign: 'center', ...a0}}>{s.text}</h1>}
      {s.type === 'quote' && <><div style={{...head, color: acc, fontSize: 220 * u, ...a0}}>«</div>
        <p style={{...body, fontSize: 84 * u, ...a1}}>{s.text}</p>
        {s.author && <p style={{...body, fontSize: 50 * u, opacity: .7, marginTop: 40 * u, ...a2}}>{s.author}</p>}</>}
      {s.type === 'list' && <><h1 style={{...head, fontSize: 88 * u, marginBottom: 56 * u, ...a0}}>{s.title}</h1>
        {(s.items ?? []).map((it, i) => <ListItem key={i} i={i} text={it} u={u} acc={acc} body={body} />)}</>}
      {s.type === 'cta' && <div style={{textAlign: 'center'}}>
        <h1 style={{...head, fontSize: 100 * u, ...a0}}>{s.title}</h1>
        {s.text && <div style={{display: 'inline-block', marginTop: 64 * u, padding: `${32 * u}px ${64 * u}px`, borderRadius: 999,
          background: c.accent, color: c.accent_text, fontFamily: 'S-head', fontSize: 56 * u, ...a1}}>{s.text}</div>}</div>}
    </AbsoluteFill>);
};

const ListItem: React.FC<{i: number; text: string; u: number; acc: string; body: React.CSSProperties}> = ({i, text, u, acc, body}) => {
  const st = useIn(10 + i * 12);
  return <div style={{display: 'flex', alignItems: 'center', gap: 36 * u, marginBottom: 48 * u, ...st}}>
    <div style={{width: 96 * u, height: 96 * u, borderRadius: 24 * u, background: acc, color: c.accent_text, fontFamily: 'S-head',
      fontSize: 48 * u, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none'}}>{i + 1}</div>
    <p style={{...body, fontSize: 68 * u}}>{text}</p></div>;
};

export const Main: React.FC<Props> = ({scenes, music}) => {
  let from = 0;
  return <AbsoluteFill>
    {scenes.map((s, i) => { const d = dur(s); const el = <Sequence key={i} from={from} durationInFrames={d}><SceneView s={s} /></Sequence>; from += d; return el; })}
    {music && <Audio src={staticFile(music)} volume={0.3} />}
  </AbsoluteFill>;
};
