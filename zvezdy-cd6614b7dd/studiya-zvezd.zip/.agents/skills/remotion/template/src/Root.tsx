import React from 'react';
import {Composition} from 'remotion';
import {Main, calcMeta, defaultProps} from './Main';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    fps={30}
    width={1080}
    height={1920}
    durationInFrames={300}
    defaultProps={defaultProps}
    calculateMetadata={calcMeta}
  />
);
