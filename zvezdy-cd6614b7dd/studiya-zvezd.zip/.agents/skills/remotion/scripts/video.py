#!/usr/bin/env python3
"""Анимированные ролики на Remotion в фирстиле школы.

Использование:
  .agents/run remotion/scripts/video.py setup
      один раз: ставит Remotion в .agents/.remotion (нужен Node.js, его ставит studio-setup), 2–5 минут
  .agents/run remotion/scripts/video.py render "Видео/2026-11-20 Анимация — тема/scenes.json"
      собирает ролик в папку задачи: готово/<имя папки>.mp4 и лист кадров превью.png
  .agents/run remotion/scripts/video.py studio
      открывает Remotion Studio в браузере для живого просмотра (по просьбе владелицы)

scenes.json:
{
 "format": "vertical",              // vertical 1080×1920, horizontal 1920×1080, square 1080×1080
 "music": "музыка.mp3",             // по желанию, файл рядом со scenes.json, звучит тихо под роликом
 "scenes": [
  {"type": "title", "title": "Почему дети бросают музыку", "text": "и что с этим делать"},
  {"type": "text", "title": "Причина 1", "text": "Скучные упражнения без любимой песни"},
  {"type": "list", "title": "Что помогает", "items": ["Песня с первого урока", "Концерт раз в полгода"], "seconds": 6},
  {"type": "big", "text": "80% урока: музыка, которую выбрал ребёнок"},
  {"type": "quote", "text": "Соня сама просит на урок", "author": "мама Сони, 9 лет"},
  {"type": "photo", "src": "фото.jpg", "title": "Отчётный концерт"},
  {"type": "video", "src": "кусок.mp4", "seconds": 6},
  {"type": "cta", "title": "Запишись на пробный урок", "text": "Ссылка в профиле"}
 ]
}
seconds у сцены по желанию (по умолчанию 3,5 с, список 5 с, видео 8 с). tone: base | accent | dark | surface.
Коды: 0 готово, 2 ошибка json или файла, 3 нет Node.js, 4 Remotion не установлен, 5 рендер упал, 6 нет фирстиля.
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

HERE = Path(__file__).resolve().parents[1]
TEMPLATE = HERE / "template"
WS = studio.STUDIO / ".agents" / ".remotion"
FILE_KEYS = ("src", "music")


def npm_cmd(name):
    exe = studio.tool(name, required=False)
    if not exe:
        studio.die(3, "Node.js не найден. Запусти скилл studio-setup: он поставит Node.js.")
    return exe


def setup():
    WS.mkdir(parents=True, exist_ok=True)
    for item in TEMPLATE.iterdir():
        dst = WS / item.name
        if item.is_dir():
            shutil.copytree(item, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(item, dst)
    (WS / "public").mkdir(exist_ok=True)
    r = subprocess.run([npm_cmd("npm"), "install", "--no-audit", "--no-fund"], cwd=WS)
    if r.returncode:
        studio.die(4, "npm install не прошёл: нужен интернет. Повтори setup.")
    r = subprocess.run([npm_cmd("npx"), "remotion", "browser", "ensure"], cwd=WS)
    if r.returncode:
        studio.die(4, "Не скачался браузер для рендера. Повтори setup.")
    print(json.dumps({"ok": True, "workspace": str(WS)}, ensure_ascii=False))


def need_ws():
    if not (WS / "node_modules" / "remotion").exists():
        studio.die(4, "Remotion не установлен. Запусти: video.py setup")


def sync_brand():
    brand = studio.load_brand()
    pub = WS / "public"
    if pub.exists():
        shutil.rmtree(pub)
    (pub / "fonts").mkdir(parents=True)
    for role in ("head", "text"):
        f = studio.font_path(brand, role)
        if f and Path(f).exists():
            shutil.copy2(f, pub / "fonts" / Path(f).name)
    (pub / "brand.json").write_text(json.dumps(brand, ensure_ascii=False), encoding="utf-8")
    return pub


def collect(obj, found):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in FILE_KEYS and isinstance(v, str):
                found.add(v)
            else:
                collect(v, found)
    elif isinstance(obj, list):
        for v in obj:
            collect(v, found)


def contact_sheet(mp4, out_png, n=8):
    ff, fp = studio.tool("ffmpeg"), studio.tool("ffprobe")
    d = float(subprocess.run([fp, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(mp4)],
                             capture_output=True, text=True).stdout.strip() or 0)
    from PIL import Image
    frames = []
    tmp = out_png.parent / ".frames"
    tmp.mkdir(exist_ok=True)
    for i in range(n):
        t = d * (i + 0.5) / n
        p = tmp / f"{i:02d}.jpg"
        subprocess.run([ff, "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", str(mp4), "-frames:v", "1", "-vf", "scale=360:-1", str(p)])
        if p.exists():
            frames.append(Image.open(p).convert("RGB"))
    if not frames:
        return
    w, h = frames[0].size
    cols = 4
    rows = (len(frames) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * w + (cols + 1) * 12, rows * h + (rows + 1) * 12), (225, 225, 225))
    for i, im in enumerate(frames):
        sheet.paste(im, (12 + (i % cols) * (w + 12), 12 + (i // cols) * (h + 12)))
    sheet.save(out_png)
    shutil.rmtree(tmp, ignore_errors=True)


def render(scenes_path):
    need_ws()
    sp = Path(scenes_path).resolve()
    try:
        data = studio.typo_deep(json.loads(sp.read_text(encoding="utf-8")), skip=("type", "tone", "format", "src", "music"))
    except Exception as e:  # noqa: BLE001
        studio.die(2, f"не читается {sp}: {e}")
    pub = sync_brand()
    files = set()
    collect(data, files)
    missing = []
    for f in files:
        src = sp.parent / f
        if not src.exists():
            missing.append(f)
            continue
        dst = pub / f
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    if missing:
        studio.die(2, "нет файлов рядом со scenes.json: " + ", ".join(missing))
    props = WS / "props.json"
    props.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    out_dir = sp.parent / "готово"
    out_dir.mkdir(exist_ok=True)
    out = out_dir / (sp.parent.name + ".mp4")
    r = subprocess.run([npm_cmd("npx"), "remotion", "render", "Main", str(out), "--props=props.json", "--log=error"], cwd=WS)
    if r.returncode or not out.exists():
        studio.die(5, "рендер упал: покажи последние строки ошибки выше простыми словами")
    prev = sp.parent / "превью.png"
    contact_sheet(out, prev)
    print(json.dumps({"ok": True, "video": str(out), "preview": str(prev)}, ensure_ascii=False, indent=1))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["setup", "render", "studio"])
    ap.add_argument("scenes", nargs="?")
    a = ap.parse_args()
    if a.cmd == "setup":
        setup()
    elif a.cmd == "render":
        if not a.scenes:
            studio.die(2, "укажи путь к scenes.json")
        render(a.scenes)
    else:
        need_ws()
        sync_brand()
        subprocess.run([npm_cmd("npx"), "remotion", "studio"], cwd=WS)


if __name__ == "__main__":
    main()
