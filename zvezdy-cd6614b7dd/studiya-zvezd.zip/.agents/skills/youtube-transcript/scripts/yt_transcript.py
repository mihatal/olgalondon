#!/usr/bin/env python3
"""Субтитры и текст с YouTube по ссылке.

Использование:
  .agents/run youtube-transcript/scripts/yt_transcript.py ССЫЛКА [опции]

Опции:
  --langs ru,en       языки готовых субтитров по приоритету (по умолчанию ru,en)
  --whisper           не брать готовые субтитры, сразу распознать речь (точнее, с пунктуацией)
  --prompt "имена"    подсказка для распознавания (имена, термины)
  --language auto     язык речи при распознавании (auto, ru, en); субтитры берутся на языке оригинала
  --out-dir ПАПКА     куда сохранить (по умолчанию «Входящие», если есть, иначе текущая папка)
  --source-address IP привязка к сетевой карте, если включён VPN и YouTube отвечает 429
  --browser chrome    взять вход в YouTube из браузера (при ошибках 403, 429, «not a bot»)

Логика: сначала ручные субтитры автора, потом автоматические YouTube. Если ни тех,
ни других нет, качает только звук и распознаёт его локально (как скилл transcribe).
Создаёт «Название видео.srt» и «Название видео.txt» (в начале txt название и ссылка).
В stdout JSON со сводкой. Коды выхода: 0 готово, 2 неверная ссылка, 6 YouTube не отдал видео.
"""
import argparse
import html
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

TRANSCRIBE = Path(__file__).resolve().parents[2] / "transcribe" / "scripts" / "transcribe.py"


def die(code, msg):
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False))
    print("ОШИБКА: " + msg, file=sys.stderr)
    sys.exit(code)


def safe_name(title):
    t = re.sub(r'[\\/:*?"<>|]+', " ", title or "video").strip()
    return re.sub(r"\s+", " ", t)[:80].rstrip(" .") or "video"


def vtt_time(s):
    h, m, rest = ("0:" + s if s.count(":") == 1 else s).split(":")
    return int(h) * 3600 + int(m) * 60 + float(rest.replace(",", "."))


def srt_time(t):
    h, rem = divmod(max(0.0, t), 3600)
    m, s = divmod(rem, 60)
    return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{int(round((s - int(s)) * 1000)) % 1000:03d}"


def parse_vtt(text):
    """VTT → список (start, end, line).
    Автосубтитры YouTube — «бегущая строка»: в каждой реплике повторяется прошлая строка,
    а новая помечена тегами времени слов <00:00:03.600><c>. Поэтому из реплики с тегами
    берём только строки с тегами; у обычных субтитров берём всё, кроме повтора прошлой строки.
    Настройки после таймкода (align:start position:0%) в текст не попадают."""
    blocks, cur = [], None
    for raw in text.replace("\r", "").splitlines():
        m = re.match(r"\s*([\d:.,]+)\s*-->\s*([\d:.,]+)", raw)
        if m:
            cur = [vtt_time(m.group(1)), vtt_time(m.group(2)), []]
            blocks.append(cur)
        elif cur is not None and raw.strip():
            cur[2].append(raw)
    cues, last_line = [], None
    for start, end, raw_lines in blocks:
        if end - start < 0.05:             # служебные реплики-переходы длиной 10 мс
            continue
        tagged = [x for x in raw_lines if "<c>" in x or re.search(r"<\d\d:\d\d", x)]
        candidates = tagged if tagged else [" ".join(x.strip() for x in raw_lines)]
        for raw in candidates:
            line = html.unescape(re.sub(r"<[^>]+>", "", raw)).strip()
            if not line or line == last_line:
                continue
            cues.append((start, end, line))
            last_line = line
    return cues


def pick_track(info, langs):
    """Ручные субтитры автора по приоритету языков, иначе автосубтитры на ЯЗЫКЕ ОРИГИНАЛА.
    Автодорожки других языков у YouTube это машинный перевод: их берём только в крайнем случае."""
    manual, auto = info.get("subtitles") or {}, info.get("automatic_captions") or {}
    for lang in langs:
        if lang in manual:
            return "manual", lang
    orig = [k for k in auto if k.endswith("-orig")]
    if orig:
        return "auto", orig[0]
    spoken = info.get("language")
    if spoken and spoken in auto:
        return "auto", spoken
    return None, None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("url")
    ap.add_argument("--langs", default="ru,en")
    ap.add_argument("--whisper", action="store_true")
    ap.add_argument("--prompt", default="")
    ap.add_argument("--language", default="auto", help="язык речи для распознавания: auto (по умолчанию), ru, en")
    ap.add_argument("--out-dir")
    ap.add_argument("--source-address", help="IP сетевой карты, если включён VPN и YouTube отвечает 429")
    ap.add_argument("--browser", choices=["chrome", "safari", "firefox", "edge", "brave", "arc"],
                    help="взять вход в YouTube из браузера (если YouTube отвечает 403/429 или просит подтвердить, что не бот)")
    args = ap.parse_args()
    if not re.match(r"https?://", args.url):
        die(2, "нужна ссылка вида https://www.youtube.com/watch?v=… или https://youtu.be/…")

    import yt_dlp

    out_dir = Path(args.out_dir) if args.out_dir else (Path("Входящие") if Path("Входящие").is_dir() else Path("."))
    out_dir.mkdir(parents=True, exist_ok=True)
    # JS-движок нужен yt-dlp, чтобы пройти проверки YouTube: deno ставит установщик, node если уже есть
    base_opts = {"quiet": True, "no_warnings": True, "noplaylist": True, "retries": 3, "noprogress": True,
                 "js_runtimes": {"deno": {}, "node": {}}}
    if args.browser:
        base_opts["cookiesfrombrowser"] = (args.browser, None, None, None)
    if args.source_address:
        base_opts["source_address"] = args.source_address
    try:
        with yt_dlp.YoutubeDL(base_opts) as ydl:
            info = ydl.extract_info(args.url, download=False)
    except Exception as e:  # noqa: BLE001
        hint = "" if args.browser else " Если причина 403/429/«not a bot», повтори с --browser chrome (или safari, firefox)."
        die(6, f"YouTube не отдал видео: {str(e)[:300]}.{hint}")
    title, vid = info.get("title") or info.get("id"), info.get("id")
    name = safe_name(title)
    srt_path, txt_path = out_dir / f"{name}.srt", out_dir / f"{name}.txt"
    header = f"# {title}\n{info.get('webpage_url', args.url)}\n\n"
    langs = [x.strip() for x in args.langs.split(",") if x.strip()]

    kind, lang = (None, None) if args.whisper else pick_track(info, langs)
    with tempfile.TemporaryDirectory() as td:
        if kind:
            print(f">> Беру готовые субтитры: {lang} ({'автор' if kind == 'manual' else 'автоматические'})", file=sys.stderr)
            opts = {**base_opts, "skip_download": True, "subtitleslangs": [lang], "subtitlesformat": "vtt",
                    "writesubtitles": kind == "manual", "writeautomaticsub": kind == "auto",
                    "outtmpl": str(Path(td) / "sub.%(ext)s")}
            try:
                with yt_dlp.YoutubeDL(opts) as ydl:
                    ydl.download([args.url])
            except Exception as e:  # noqa: BLE001  (частое: HTTP 429 у субтитров при VPN)
                print(f">> Субтитры не отдали ({str(e)[-80:]})", file=sys.stderr)
            vtts = list(Path(td).glob("*.vtt"))
            if vtts:
                cues = parse_vtt(vtts[0].read_text(encoding="utf-8", errors="ignore"))
                with open(srt_path, "w", encoding="utf-8") as f:
                    for i, (a, b, line) in enumerate(cues, 1):
                        f.write(f"{i}\n{srt_time(a)} --> {srt_time(b)}\n{line}\n\n")
                txt_path.write_text(header + " ".join(c[2] for c in cues) + "\n", encoding="utf-8")
                print(json.dumps({"ok": True, "title": title, "id": vid, "source": f"subtitles:{kind}:{lang}",
                                  "srt": str(srt_path), "txt": str(txt_path), "lines": len(cues),
                                  "note": "автосубтитры без пунктуации; для точного текста запусти с --whisper"
                                  if kind == "auto" else None}, ensure_ascii=False, indent=1))
                return
            print(">> Субтитры не скачались, перехожу к распознаванию", file=sys.stderr)

        print(">> Качаю только звук и распознаю речь локально", file=sys.stderr)
        opts = {**base_opts, "format": "bestaudio[ext=m4a]/bestaudio", "outtmpl": str(Path(td) / "audio.%(ext)s")}
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download([args.url])
        except Exception as e:  # noqa: BLE001
            hint = "" if args.browser else " Повтори с --browser chrome (или safari, firefox): браузер, где выполнен вход в YouTube."
            die(6, f"не удалось скачать звук: {str(e)[:300]}.{hint}")
        audio = next(Path(td).glob("audio.*"), None)
        if not audio:
            die(6, "звук не скачался")
        named = Path(td) / f"{name}{audio.suffix}"
        audio.rename(named)
        lang = args.language
        if lang == "auto" and (info.get("language") or "")[:2] in ("ru", "en"):
            lang = info["language"][:2]
        cmd = [sys.executable, str(TRANSCRIBE), str(named), "--out-dir", str(out_dir), "--force", "--language", lang]
        if args.prompt:
            cmd += ["--prompt", args.prompt]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            die(r.returncode, "распознавание не прошло: " + (r.stderr.strip()[-400:] or r.stdout[-400:]))
        if txt_path.exists():
            txt_path.write_text(header + txt_path.read_text(encoding="utf-8"), encoding="utf-8")
        print(json.dumps({"ok": True, "title": title, "id": vid, "source": "whisper",
                          "srt": str(srt_path), "txt": str(txt_path),
                          "words": str(out_dir / f"{name}_words.json")}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    studio.tool("ffmpeg")
    main()
