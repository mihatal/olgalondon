#!/usr/bin/env python3
"""Проверка стыков смонтированного ролика на слух: каждый стык заново распознаётся.

Использование:
  .agents/run talking-head-cut/scripts/qc_joins.py ГОТОВОЕ.mp4 [--joins ГОТОВОЕ_joins.json] [--window 2.6]

Для каждого стыка берёт звук ±2,6 с, распознаёт и ищет:
  repeat   — одни и те же слова по обе стороны стыка (огрызок дубля, перезаход)
  cut_word — на стыке невнятный огрызок слова (слово на стыке распознано с уверенностью < 0,5)
  silence  — у стыка нет речи с одной стороны дольше 1 с (лишняя дыра)
Флаг — подозрение, не приговор: окно через стык иногда само выдумывает «это | это».
Подозрительное место проверь отдельным прослушиванием.
В stdout JSON: все стыки с текстом вида «…слова до | слова после…» и флагами.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402



def norm(w):
    return re.sub(r"[^\wё]+", "", w.lower())


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--joins")
    ap.add_argument("--window", type=float, default=2.6)
    ap.add_argument("--language", default="ru")
    a = ap.parse_args()
    ff = studio.tool("ffmpeg")
    v = Path(a.video)
    jp = Path(a.joins) if a.joins else v.with_name(v.stem + "_joins.json")
    if not jp.exists():
        print(json.dumps({"ok": False, "error": f"нет файла стыков {jp} (его пишет cut.py рядом с результатом)"}, ensure_ascii=False))
        sys.exit(4)
    joins = json.load(open(jp, encoding="utf-8"))["joins"]
    report = []
    with tempfile.TemporaryDirectory() as td:
        for k, j in enumerate(joins, 1):
            t0 = max(0.0, j - a.window)
            wav = Path(td) / f"j{k}.wav"
            subprocess.run([ff, "-v", "error", "-y", "-ss", f"{t0:.3f}", "-t", f"{2 * a.window:.3f}", "-i", str(v),
                            "-vn", "-ac", "1", "-ar", "16000", str(wav)], check=True)
            res = studio.transcribe(wav, language=a.language)
            ws = [w for s in res.get("segments", []) for w in (s.get("words") or [])]
            jt = j - t0
            # слово относится к той стороне стыка, где его середина: Whisper растягивает слова через паузу
            before = [w for w in ws if (w["start"] + w["end"]) / 2 <= jt]
            after = [w for w in ws if (w["start"] + w["end"]) / 2 > jt]
            flags = []
            # обрыв: слово лежит на стыке И распознано неуверенно (огрызок звучит как невнятный слог)
            if any(w["start"] < jt - 0.06 and w["end"] > jt + 0.06 and w.get("probability", 1) < 0.5 for w in ws):
                flags.append("cut_word")
            b3, a3 = [norm(w["word"]) for w in before[-3:]], [norm(w["word"]) for w in after[:3]]
            if b3 and a3 and (b3[-1] == a3[0] or (len(b3) >= 2 and b3[-2:] == a3[:2])):
                flags.append("repeat")
            if (before and jt - before[-1]["end"] > 1.0) or (after and after[0]["start"] - jt > 1.0):
                flags.append("silence")
            text = " ".join(w["word"].strip() for w in before) + "  |  " + " ".join(w["word"].strip() for w in after)
            report.append({"join": k, "time": round(j, 2), "text": text.strip(), "flags": flags})
            print(f">> стык {k}/{len(joins)}", file=sys.stderr)
    bad = [r for r in report if r["flags"]]
    print(json.dumps({"ok": True, "joins": len(report), "suspicious": len(bad), "report": report}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
