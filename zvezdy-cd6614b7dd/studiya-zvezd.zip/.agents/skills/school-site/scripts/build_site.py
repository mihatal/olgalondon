#!/usr/bin/env python3
"""Собрать сайт школы в фирстиле из site.json: обычный HTML, который открывается везде и индексируется поисковиками.

Использование:
  .agents/run school-site/scripts/build_site.py "Сайты/Сайт школы/site.json"
  ... --out "Сайты/Сайт школы/сайт"     (по умолчанию папка «сайт» рядом с site.json)
  ... --noindex                         скрыть от поисковиков (для черновика)

site.json (любой блок можно убрать, порядок блоков = порядок в "sections"):
{
 "seo": {"title": "Школа вокала Звезда в Казани", "description": "..."},
 "sections": [
  {"type": "hero", "title": "...", "text": "...", "button": "Записаться на пробный урок", "photo": "фото/главное.jpg", "facts": ["с 2015 года", "320 учеников"]},
  {"type": "directions", "title": "Чему учим", "items": [{"title": "Вокал", "text": "...", "age": "6–14 лет", "photo": "..."}]},
  {"type": "steps", "title": "Как проходит пробный урок", "items": [{"title": "...", "text": "..."}]},
  {"type": "teachers", "title": "Педагоги", "items": [{"name": "...", "role": "...", "text": "...", "photo": "..."}]},
  {"type": "results", "title": "Результаты учеников", "items": [{"title": "...", "text": "...", "photo": "..."}]},
  {"type": "reviews", "title": "Отзывы", "items": [{"text": "...", "author": "Мама Сони, 9 лет"}]},
  {"type": "prices", "title": "Форматы и цены", "items": [{"title": "Индивидуально", "price": "2 500 ₽", "per": "за урок 45 минут", "points": ["..."], "accent": true}], "note": "..."},
  {"type": "faq", "title": "Частые вопросы", "items": [{"q": "...", "a": "..."}]},
  {"type": "contacts", "title": "Записаться", "text": "...", "address": "...", "hours": "..."}
 ]
}
Кнопки «Записаться» ведут на контакты из Бренд/brand.json (Telegram, WhatsApp, телефон).
Создаёт папку с index.html, brand.css, fonts/, фото. Коды: 0 готово, 2 ошибка site.json, 6 нет фирстиля.
"""
import argparse
import html
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

E = lambda s: html.escape(studio.typo(str(s or "")), quote=True)  # noqa: E731
ROBOTS = '<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex">'

CSS = """
*{box-sizing:border-box;margin:0;padding:0}html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}
body{background:var(--bg);color:var(--text);font-family:var(--font-text);font-size:18px;line-height:1.55}
img{max-width:100%;display:block}a{color:inherit}
.w{max-width:1120px;margin:0 auto;padding:0 20px}
section{padding:72px 0}section.alt{background:var(--surface)}
h1,h2,h3{font-family:var(--font-head);font-weight:var(--head-weight);line-height:1.1}
h1{font-size:clamp(34px,6vw,64px);margin-bottom:18px}h2{font-size:clamp(28px,4.5vw,44px);margin-bottom:28px}h3{font-size:22px;margin-bottom:8px}
.lead{font-size:clamp(18px,2.2vw,22px);color:var(--muted);max-width:620px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:var(--accent);color:var(--accent-text);text-decoration:none;font-weight:700;border-radius:999px;padding:16px 28px;min-height:52px;border:0;font-size:18px}
.btn.ghost{background:transparent;color:var(--text);box-shadow:inset 0 0 0 2px var(--muted)}
.top{position:sticky;top:0;z-index:5;background:var(--bg);border-bottom:1px solid rgba(127,127,127,.15)}
.top .w{display:flex;align-items:center;justify-content:space-between;height:64px;gap:12px}
.logo{display:flex;align-items:center;gap:10px;font-family:var(--font-head);font-weight:var(--head-weight);font-size:20px;text-decoration:none}
.logo img{height:36px;width:auto}
.top .btn{padding:10px 18px;min-height:42px;font-size:16px}
.hero{padding:56px 0 72px}.hero .w{display:grid;grid-template-columns:1.1fr .9fr;gap:40px;align-items:center}
.hero .ph{border-radius:calc(var(--radius) * 2);overflow:hidden;aspect-ratio:4/5;background:var(--surface)}
.hero .ph img{width:100%;height:100%;object-fit:cover}
.facts{display:flex;flex-wrap:wrap;gap:10px;margin:22px 0 28px}
.facts span{background:var(--surface);border-radius:999px;padding:8px 14px;font-weight:700;font-size:16px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:20px}\n.hero .w.solo{grid-template-columns:1fr;max-width:900px}
.card{background:var(--bg);border-radius:var(--radius);padding:24px;box-shadow:0 2px 16px rgba(0,0,0,.06)}
section:not(.alt) .card{background:var(--surface)}
.card .ph{border-radius:calc(var(--radius) - 4px);overflow:hidden;aspect-ratio:4/3;margin:-8px -8px 16px}
.card .ph img{width:100%;height:100%;object-fit:cover}
.tag{display:inline-block;color:var(--accent);font-weight:700;font-size:15px;margin-bottom:6px}
.muted{color:var(--muted)}
.steps{counter-reset:s;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px}
.steps .card::before{counter-increment:s;content:counter(s);display:flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:50%;background:var(--accent);color:var(--accent-text);font-weight:800;margin-bottom:14px}
.teacher .ph{aspect-ratio:1/1;border-radius:50%;width:150px;margin:0 0 16px}
.review{font-size:19px}.review .who{margin-top:14px;font-weight:700;color:var(--muted);font-size:16px}
.price .sum{font-family:var(--font-head);font-weight:var(--head-weight);font-size:36px;margin:8px 0 2px}
.price ul{list-style:none;margin:16px 0 22px}.price li{padding:6px 0 6px 28px;position:relative}
.price li::before{content:"✓";position:absolute;left:0;color:var(--accent);font-weight:800}
.price.acc{box-shadow:inset 0 0 0 3px var(--accent)}
details{background:var(--surface);border-radius:var(--radius);padding:18px 22px;margin-bottom:12px}
section.alt details{background:var(--bg)}
summary{cursor:pointer;font-weight:700;font-size:19px;list-style:none}summary::-webkit-details-marker{display:none}
summary::after{content:"+";float:right;color:var(--accent);font-size:24px;line-height:1}details[open] summary::after{content:"−"}
details p{margin-top:12px;color:var(--muted)}
.cta{background:var(--dark);color:#fff}.cta .lead{color:rgba(255,255,255,.75)}
.cta .row{display:flex;flex-wrap:wrap;gap:12px;margin-top:26px}.cta .btn.ghost{color:#fff;box-shadow:inset 0 0 0 2px rgba(255,255,255,.5)}
.cta .info{margin-top:24px;color:rgba(255,255,255,.75)}
footer{padding:28px 0;color:var(--muted);font-size:15px;text-align:center}
@media (max-width:820px){.hero .w{grid-template-columns:1fr}.hero .ph{aspect-ratio:4/3;order:-1}section{padding:56px 0}.top .logo img+span{display:none}}
"""


def contact_buttons(c, primary_label):
    out = []
    first = True
    for key, label in (("telegram", "Telegram"), ("whatsapp", "WhatsApp"), ("phone", "Позвонить"), ("site", "Сайт")):
        v = (c or {}).get(key)
        if not v:
            continue
        href = v
        if key == "phone":
            href = "tel:" + "".join(ch for ch in v if ch.isdigit() or ch == "+")
        if key == "whatsapp" and not v.startswith("http"):
            href = "https://wa.me/" + "".join(ch for ch in v if ch.isdigit())
        txt = primary_label if first else label
        tgt = "" if href.startswith("tel:") else ' target="_blank" rel="noopener"'
        if key == "phone":
            txt = (primary_label if first else "Позвонить: ") + ("" if first else v)
        out.append(f'<a class="btn{"" if first else " ghost"}" href="{E(href)}"{tgt}>{E(txt)}</a>')
        first = False
    return out


def first_link(c):
    b = contact_buttons(c, "x")
    return b[0].split('href="')[1].split('"')[0] if b else "#contacts"


def img(rel, alt, files):
    if not rel:
        return ""
    files.add(rel)
    return f'<div class="ph"><img src="{E(rel)}" alt="{E(alt)}" loading="lazy"></div>'


def render(site, brand, files):
    c = brand.get("contacts") or {}
    link = first_link(c)
    parts = []
    alt = False
    for s in site.get("sections", []):
        t = s.get("type")
        cls = ' class="alt"' if alt else ""
        items = s.get("items", [])
        if t == "hero":
            facts = "".join(f"<span>{E(f)}</span>" for f in s.get("facts", []))
            solo = "" if s.get("photo") else " solo"
            parts.append(f'<section class="hero"><div class="w{solo}"><div><h1>{E(s.get("title"))}</h1><p class="lead">{E(s.get("text"))}</p>'
                         f'{"<div class=facts>" + facts + "</div>" if facts else "<div style=height:28px></div>"}'
                         f'<a class="btn" href="{E(link)}" target="_blank" rel="noopener">{E(s.get("button", "Записаться"))}</a></div>'
                         f'{img(s.get("photo"), brand["school"], files)}</div></section>')
            alt = True
            continue
        body = ""
        if t == "directions":
            body = '<div class="grid">' + "".join(
                f'<div class="card">{img(i.get("photo"), i.get("title"), files)}{"<span class=tag>" + E(i["age"]) + "</span>" if i.get("age") else ""}'
                f'<h3>{E(i.get("title"))}</h3><p class="muted">{E(i.get("text"))}</p></div>' for i in items) + "</div>"
        elif t == "steps":
            body = '<div class="steps">' + "".join(f'<div class="card"><h3>{E(i.get("title"))}</h3><p class="muted">{E(i.get("text"))}</p></div>' for i in items) + "</div>"
        elif t == "teachers":
            body = '<div class="grid">' + "".join(
                f'<div class="card teacher">{img(i.get("photo"), i.get("name"), files)}<h3>{E(i.get("name"))}</h3>'
                f'<span class="tag">{E(i.get("role"))}</span><p class="muted">{E(i.get("text"))}</p></div>' for i in items) + "</div>"
        elif t == "results":
            body = '<div class="grid">' + "".join(
                f'<div class="card">{img(i.get("photo"), i.get("title"), files)}<h3>{E(i.get("title"))}</h3><p class="muted">{E(i.get("text"))}</p></div>' for i in items) + "</div>"
        elif t == "reviews":
            body = '<div class="grid">' + "".join(
                f'<div class="card review"><p>«{E(i.get("text"))}»</p><p class="who">{E(i.get("author"))}</p></div>' for i in items) + "</div>"
        elif t == "prices":
            body = '<div class="grid">' + "".join(
                f'<div class="card price{" acc" if i.get("accent") else ""}"><h3>{E(i.get("title"))}</h3><div class="sum">{E(i.get("price"))}</div>'
                f'<div class="muted">{E(i.get("per"))}</div><ul>{"".join("<li>" + E(p) + "</li>" for p in i.get("points", []))}</ul>'
                f'<a class="btn{"" if i.get("accent") else " ghost"}" href="{E(link)}" target="_blank" rel="noopener">{E(i.get("button", "Записаться"))}</a></div>'
                for i in items) + "</div>" + (f'<p class="muted" style="margin-top:20px">{E(s["note"])}</p>' if s.get("note") else "")
        elif t == "faq":
            body = "".join(f"<details><summary>{E(i.get('q'))}</summary><p>{E(i.get('a'))}</p></details>" for i in items)
        elif t == "contacts":
            info = " · ".join(E(x) for x in (s.get("address"), s.get("hours")) if x)
            parts.append(f'<section class="cta" id="contacts"><div class="w"><h2>{E(s.get("title", "Записаться"))}</h2>'
                         f'<p class="lead">{E(s.get("text"))}</p><div class="row">{"".join(contact_buttons(c, s.get("button", "Записаться")))}</div>'
                         f'{"<p class=info>" + info + "</p>" if info else ""}</div></section>')
            continue
        else:
            continue
        parts.append(f'<section{cls}><div class="w"><h2>{E(s.get("title"))}</h2>{body}</div></section>')
        alt = not alt
    return "\n".join(parts)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("site")
    ap.add_argument("--out")
    ap.add_argument("--noindex", action="store_true")
    a = ap.parse_args()
    brand = studio.load_brand()
    if not (studio.BRAND_DIR / "brand.css").exists():
        studio.die(6, "нет Бренд/brand.css. Запусти znakomstvo/scripts/apply_brand.py")
    sp = Path(a.site)
    try:
        site = json.loads(sp.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        studio.die(2, f"не читается {sp}: {e}")
    out = Path(a.out) if a.out else sp.parent / "сайт"
    out.mkdir(parents=True, exist_ok=True)
    files = set()
    body = render(site, brand, files)
    logo_html = ""
    if brand.get("logo") and (studio.STUDIO / brand["logo"]).exists():
        lg = studio.STUDIO / brand["logo"]
        shutil.copy2(lg, out / ("logo" + lg.suffix))
        logo_html = f'<img src="logo{lg.suffix}" alt="">'
    seo = site.get("seo", {})
    c = brand.get("contacts") or {}
    top_btn = f'<a class="btn" href="{E(first_link(c))}" target="_blank" rel="noopener">Записаться</a>' if contact_buttons(c, "x") else ""
    page = f"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
{ROBOTS if a.noindex else ""}<title>{E(seo.get("title", brand["school"]))}</title>
<meta name="description" content="{E(seo.get("description", brand.get("niche", "")))}">
<meta property="og:title" content="{E(seo.get("title", brand["school"]))}"><meta property="og:description" content="{E(seo.get("description", ""))}">
<link rel="stylesheet" href="brand.css"><style>{CSS}</style></head><body>
<header class="top"><div class="w"><a class="logo" href="#">{logo_html}<span>{E(brand["school"])}</span></a>{top_btn}</div></header>
<main>
{body}
</main>
<footer><div class="w">© {E(brand["school"])}{" · " + E(brand.get("city")) if brand.get("city") else ""}</div></footer>
</body></html>"""
    (out / "index.html").write_text(page, encoding="utf-8")
    shutil.copy2(studio.BRAND_DIR / "brand.css", out / "brand.css")
    (out / "fonts").mkdir(exist_ok=True)
    for f in (studio.BRAND_DIR / "fonts").glob("*"):
        if f.suffix.lower() in (".ttf", ".otf", ".woff", ".woff2"):
            shutil.copy2(f, out / "fonts" / f.name)
    missing = []
    for rel in files:
        src = next((p for p in (sp.parent / rel, studio.STUDIO / rel) if p.exists()), None)
        if not src:
            missing.append(rel)
            continue
        dst = out / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.resolve() != dst.resolve():
            shutil.copy2(src, dst)
    print(json.dumps({"ok": True, "folder": str(out), "open": str(out / "index.html"), "missing_photos": missing,
                      "no_contacts": not contact_buttons(c, "x")}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
