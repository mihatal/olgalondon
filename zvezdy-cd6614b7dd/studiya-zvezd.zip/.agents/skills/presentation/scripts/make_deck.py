#!/usr/bin/env python3
"""Собрать редактируемую презентацию .pptx в фирстиле школы (открывается в PowerPoint, Keynote, Google Slides).

Использование:
  .agents/run presentation/scripts/make_deck.py "Презентации/2026-11-20 Пробный урок/deck.json"
  ... --out "Презентации/.../Пробный урок.pptx"   (по умолчанию рядом с deck.json, имя из title)

deck.json:
{
 "title": "Пробный урок вокала",
 "slides": [
  {"type": "cover", "title": "...", "subtitle": "...", "photo": "Бренд/фото/педагог.jpg"},
  {"type": "statement", "text": "Одна мысль крупно", "tone": "accent"},
  {"type": "bullets", "title": "...", "items": ["...", "..."]},
  {"type": "stat", "value": "12", "caption": "учеников за месяц"},
  {"type": "photo", "title": "...", "photo": "...", "caption": "..."},
  {"type": "compare", "title": "...", "left": {"title": "Было", "items": []}, "right": {"title": "Стало", "items": []}},
  {"type": "prices", "title": "...", "items": [{"title": "Индивидуально", "price": "2 900 ₽", "per": "за 60 минут", "points": ["..."], "accent": true}]},
  {"type": "quote", "text": "...", "author": "..."},
  {"type": "cta", "title": "...", "text": "...", "button": "Записаться"}
 ]
}
У любого слайда: "notes" (заметки докладчика) и "tone": base | accent | dark | surface.

Создаёт: .pptx и рядом «<имя>_превью.png» (все слайды листом) для проверки глазами.
Кегль подбирается так, чтобы текст влез в свою область; если не влезает даже на минимальном,
скрипт пишет предупреждение «режь текст» с номером слайда. Коды: 0 готово, 2 ошибка deck.json, 3 нет шрифта, 6 нет фирстиля.
"""
import argparse
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

W, H = 1280, 720            # px, слайд 16:9 (13,333 × 7,5 дюйма при 96 px/дюйм)
EMU_PX = 9525               # EMU на пиксель при 96 dpi
PT_PX = 0.75                # пунктов на пиксель
M = 80                      # поля


def rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def is_light(h):
    r, g, b = rgb(h)
    return (0.299 * r + 0.587 * g + 0.114 * b) > 150


class Style:
    def __init__(self, brand):
        self.b = brand
        c = brand["colors"]
        light_on_dark = c["bg"] if is_light(c["bg"]) else "#FFFFFF"
        self.tones = {
            "base": (c["bg"], c["text"], c["accent"], c["muted"]),
            "surface": (c["surface"], c["text"], c["accent"], c["muted"]),
            "accent": (c["accent"], c["accent_text"], c["accent_text"], c["accent_text"]),
            "dark": (c["dark"], light_on_dark, c["accent"], light_on_dark),
        }
        self.font_files = {r: str(studio.font_path(brand, r)) for r in ("head", "text")}
        self.font_names = {r: brand["fonts"][r].get("pptx_name") or brand["fonts"][r]["family"] for r in ("head", "text")}
        # жирный флаг нужен, когда у жирного файла то же имя семейства, что у обычного (Rubik 700 = «Rubik»)
        self.bold = {r: brand["fonts"][r].get("weight", 400) >= 600 and self.font_names[r] == brand["fonts"]["text"].get("pptx_name", brand["fonts"]["text"]["family"]) for r in ("head", "text")}
        self.cache = {}

    def font(self, role, px):
        k = (role, px)
        if k not in self.cache:
            self.cache[k] = ImageFont.truetype(self.font_files[role], px)
        return self.cache[k]


def wrap(st, role, text, px, max_w):
    f = st.font(role, px)
    lines = []
    for para in str(text).split("\n"):
        cur = ""
        for w in para.split(" "):
            t = (cur + " " + w).strip()
            if f.getlength(t) <= max_w or not cur:
                cur = t
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
    return lines


def fit(st, role, text, box_w, box_h, px_max, px_min, lh=1.18):
    """Самый крупный кегль, при котором текст влезает в рамку. Возвращает (px, lines, влезло)."""
    px = px_max
    while px >= px_min:
        lines = wrap(st, role, text, px, box_w * 0.94)
        if len(lines) * px * lh <= box_h and all(st.font(role, px).getlength(ln) <= box_w * 0.97 for ln in lines):
            return px, lines, True
        px -= 2
    return px_min, wrap(st, role, text, px_min, box_w * 0.94), False


def layout(slide, st):
    """Список элементов слайда: text(role, x,y,w,h, text, px_max, px_min, color, align) и image/rect."""
    t = slide.get("type", "bullets")
    bg, fg, acc, mut = st.tones[slide.get("tone") or {"statement": "accent", "cta": "dark", "quote": "surface"}.get(t, "base")]
    els = [{"kind": "rect", "box": (0, 0, W, H), "fill": bg}]
    T = lambda role, box, text, mx, mn, color, align="left", bullets=False: els.append(  # noqa: E731
        {"kind": "text", "role": role, "box": box, "text": text, "max": mx, "min": mn, "color": color,
         "align": align, "bullets": bullets})
    if t == "cover":
        photo = slide.get("photo")
        tw = W * 0.55 if photo else W - 2 * M
        if photo:
            els.append({"kind": "image", "box": (int(W * 0.58), 0, W - int(W * 0.58), H), "path": photo})
        T("head", (M, 170, tw - M, 260), slide.get("title", ""), 84, 40, fg)
        if slide.get("subtitle"):
            T("text", (M, 450, tw - M, 120), slide["subtitle"], 34, 20, mut)
        els.append({"kind": "rect", "box": (M, 140, 120, 10), "fill": acc})
    elif t == "statement":
        T("head", (M, M, W - 2 * M, H - 2 * M), slide.get("text", ""), 110, 40, fg, "center")
    elif t == "stat":
        T("head", (M, 120, W - 2 * M, 300), slide.get("value", ""), 220, 80, acc, "center")
        T("text", (M + 100, 450, W - 2 * M - 200, 160), slide.get("caption", ""), 44, 22, fg, "center")
    elif t == "photo":
        T("head", (M, 50, W - 2 * M, 100), slide.get("title", ""), 56, 28, fg)
        els.append({"kind": "image", "box": (M, 170, W - 2 * M, 440 if slide.get("caption") else 500), "path": slide.get("photo")})
        if slide.get("caption"):
            T("text", (M, 625, W - 2 * M, 60), slide["caption"], 28, 16, mut)
    elif t == "compare":
        T("head", (M, 50, W - 2 * M, 100), slide.get("title", ""), 56, 28, fg)
        cw = (W - 2 * M - 40) // 2
        for k, side in enumerate(("left", "right")):
            x = M + k * (cw + 40)
            s = slide.get(side, {})
            els.append({"kind": "rect", "box": (x, 180, cw, 460), "fill": st.tones["surface"][0] if bg != st.tones["surface"][0] else st.tones["base"][0], "radius": True})
            T("head", (x + 36, 205, cw - 72, 70), s.get("title", ""), 40, 22, acc if k else mut)
            T("text", (x + 36, 290, cw - 72, 330), "\n".join(s.get("items", [])), 40, 16, st.tones["surface"][1], bullets=True)
    elif t == "prices":
        T("head", (M, 50, W - 2 * M, 100), slide.get("title", ""), 56, 28, fg)
        items = slide.get("items", [])[:3]
        n = max(len(items), 1)
        cw = (W - 2 * M - 30 * (n - 1)) // n
        for k, it in enumerate(items):
            x = M + k * (cw + 30)
            hi = it.get("accent")
            els.append({"kind": "rect", "box": (x, 180, cw, 460), "radius": True,
                        "fill": st.b["colors"]["accent"] if hi else (st.tones["surface"][0] if bg != st.tones["surface"][0] else st.tones["base"][0])})
            col = st.b["colors"]["accent_text"] if hi else st.tones["surface"][1]
            T("text", (x + 32, 205, cw - 64, 60), it.get("title", ""), 34, 18, col)
            T("head", (x + 32, 270, cw - 64, 110), it.get("price", ""), 72, 30, col)
            T("text", (x + 32, 390, cw - 64, 230), "\n".join([it.get("per", "")] + it.get("points", [])), 28, 16, col)
    elif t == "quote":
        T("head", (M, 60, 160, 160), "«", 200, 120, acc)
        T("text", (M + 100, 170, W - 2 * M - 160, 330), slide.get("text", ""), 54, 24, fg)
        if slide.get("author"):
            T("text", (M + 100, 540, W - 2 * M - 160, 60), slide["author"], 30, 18, mut)
    elif t == "cta":
        T("head", (M, 130, W - 2 * M, 220), slide.get("title", ""), 84, 36, fg, "center")
        if slide.get("text"):
            T("text", (M + 120, 360, W - 2 * M - 240, 110), slide["text"], 36, 18, fg, "center")
        if slide.get("button"):
            bw = 460
            c = st.b.get("contacts") or {}
            link = slide.get("link") or c.get("telegram") or c.get("site") or ("tel:" + c["phone"].replace(" ", "").replace("-", "") if c.get("phone") else None)
            els.append({"kind": "rect", "box": ((W - bw) // 2, 510, bw, 96), "fill": st.b["colors"]["accent"], "radius": True,
                        "label": slide["button"], "label_color": st.b["colors"]["accent_text"], "link": link})
    else:  # bullets
        T("head", (M, 50, W - 2 * M, 120), slide.get("title", ""), 60, 28, fg)
        T("text", (M, 200, W - 2 * M, 450), "\n".join(slide.get("items", [])), 52, 18, fg, bullets=True)
    return els


def resolve(p, base):
    if not p:
        return None
    for cand in (Path(p), base / p, studio.STUDIO / p):
        if cand.exists():
            return cand
    return None


def cropped(path, w, h, tmp):
    im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
    im = ImageOps.fit(im, (w * 2, h * 2), method=Image.LANCZOS, centering=(0.5, 0.4))
    out = tmp / f"img_{abs(hash((str(path), w, h)))}.jpg"
    im.save(out, quality=90)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("deck")
    ap.add_argument("--out")
    a = ap.parse_args()
    brand = studio.load_brand()
    st = Style(brand)
    dp = Path(a.deck)
    if not dp.is_absolute():
        dp = (Path.cwd() / dp)
    try:
        deck = studio.typo_deep(json.loads(dp.read_text(encoding="utf-8")), skip=("photo", "type", "tone", "notes"))
    except Exception as e:  # noqa: BLE001
        studio.die(2, f"не читается {dp}: {e}")
    base = dp.parent
    out = Path(a.out) if a.out else base / f"{deck.get('title', 'Презентация')}.pptx"
    tmp = base / ".tmp_deck"
    tmp.mkdir(exist_ok=True)

    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.util import Emu, Pt

    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(W * EMU_PX), Emu(H * EMU_PX)
    blank = prs.slide_layouts[6]
    previews, warnings = [], []
    E = lambda v: Emu(int(v * EMU_PX))  # noqa: E731

    for n, slide in enumerate(deck.get("slides", []), 1):
        s = prs.slides.add_slide(blank)
        img = Image.new("RGB", (W, H))
        d = ImageDraw.Draw(img)
        for el in layout(slide, st):
            x, y, w, h = el["box"]
            if el["kind"] == "rect":
                shp = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if el.get("radius") else MSO_SHAPE.RECTANGLE,
                                         E(x), E(y), E(w), E(h))
                shp.fill.solid()
                shp.fill.fore_color.rgb = RGBColor(*rgb(el["fill"]))
                shp.line.fill.background()
                shp.shadow.inherit = False
                if el.get("radius"):
                    shp.adjustments[0] = 0.18 if el.get("label") is None else 0.5
                    d.rounded_rectangle((x, y, x + w, y + h), radius=min(h // 2, 40) if el.get("label") else 26, fill=rgb(el["fill"]))
                else:
                    d.rectangle((x, y, x + w, y + h), fill=rgb(el["fill"]))
                if el.get("label"):
                    px, lines, ok = fit(st, "head", el["label"], w - 40, h - 20, 40, 20)
                    tf = shp.text_frame
                    tf.word_wrap = True
                    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
                    p = tf.paragraphs[0]
                    p.alignment = PP_ALIGN.CENTER
                    r = p.add_run()
                    r.text = el["label"]
                    r.font.size, r.font.name, r.font.bold = Pt(px * PT_PX), st.font_names["head"], st.bold["head"] or None
                    r.font.color.rgb = RGBColor(*rgb(el["label_color"]))
                    if el.get("link"):
                        r.hyperlink.address = el["link"]
                    d.text((x + w / 2, y + h / 2), el["label"], font=st.font("head", px), fill=rgb(el["label_color"]), anchor="mm")
            elif el["kind"] == "image":
                src = resolve(el.get("path"), base)
                if not src:
                    warnings.append(f"слайд {n}: нет фото {el.get('path')}, поставлен серый прямоугольник")
                    shp = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, E(x), E(y), E(w), E(h))
                    shp.fill.solid()
                    shp.fill.fore_color.rgb = RGBColor(200, 200, 200)
                    shp.line.fill.background()
                    d.rectangle((x, y, x + w, y + h), fill=(200, 200, 200))
                    continue
                c = cropped(src, w, h, tmp)
                s.shapes.add_picture(str(c), E(x), E(y), E(w), E(h))
                img.paste(Image.open(c).resize((w, h)), (x, y))
            else:
                text = el["text"]
                if el["bullets"]:
                    text = "\n".join("• " + ln for ln in text.split("\n") if ln.strip())
                px, lines, ok = fit(st, el["role"], text, w, h, el["max"], el["min"])
                if not ok:
                    warnings.append(f"слайд {n}: текст не влезает даже мелким кеглем, режь текст")
                tb = s.shapes.add_textbox(E(x), E(y), E(w), E(h))
                tf = tb.text_frame
                tf.word_wrap = True
                tf.auto_size = None
                tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
                tf.vertical_anchor = MSO_ANCHOR.MIDDLE if el["align"] == "center" else MSO_ANCHOR.TOP
                for i, para in enumerate(text.split("\n")):
                    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
                    p.alignment = {"center": PP_ALIGN.CENTER, "left": PP_ALIGN.LEFT}[el["align"]]
                    p.line_spacing = 1.1
                    if el["bullets"] and i:
                        p.space_before = Pt(px * PT_PX * 0.5)
                    r = p.add_run()
                    r.text = para
                    r.font.size, r.font.name, r.font.bold = Pt(px * PT_PX), st.font_names[el["role"]], st.bold[el["role"]] or None
                    r.font.color.rgb = RGBColor(*rgb(el["color"]))
                f = st.font(el["role"], px)
                total = len(lines) * px * 1.18
                yy = y + (h - total) / 2 if el["align"] == "center" else y
                for ln in lines:
                    xx = x + w / 2 if el["align"] == "center" else x
                    d.text((xx, yy), ln, font=f, fill=rgb(el["color"]), anchor="ma" if el["align"] == "center" else "la")
                    yy += px * 1.18
        if slide.get("notes"):
            s.notes_slide.notes_text_frame.text = slide["notes"]
        logo = resolve(brand.get("logo"), base)
        if logo and slide.get("type") == "cover":
            lg = Image.open(logo).convert("RGBA")
            lg.thumbnail((140, 140))
            s.shapes.add_picture(str(logo), E(M), E(H - 60 - lg.height), E(lg.width), E(lg.height))
            img.paste(lg, (M, H - 60 - lg.height), lg)
        previews.append(img)

    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    cols = 3
    th_w, th_h = 640, 360
    rows = (len(previews) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * th_w + (cols + 1) * 20, rows * th_h + (rows + 1) * 20), (225, 225, 225))
    for i, im in enumerate(previews):
        sheet.paste(im.resize((th_w, th_h)), (20 + (i % cols) * (th_w + 20), 20 + (i // cols) * (th_h + 20)))
    prev = out.with_name(out.stem + "_превью.png")
    sheet.save(prev)
    for f in tmp.glob("*"):
        f.unlink()
    tmp.rmdir()
    print(json.dumps({"ok": True, "pptx": str(out), "preview": str(prev), "slides": len(previews),
                      "warnings": warnings}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
