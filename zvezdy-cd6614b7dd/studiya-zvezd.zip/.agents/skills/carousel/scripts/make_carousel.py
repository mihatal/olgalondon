#!/usr/bin/env python3
"""Собрать карусель для Instagram или Telegram в фирстиле школы: PNG-слайды 1080×1350.

Использование:
  .agents/run carousel/scripts/make_carousel.py "Карусели/2026-11-20 Почему дети бросают музыку/carousel.json"

carousel.json:
{
 "title": "Почему дети бросают музыку",
 "slides": [
  {"type": "cover", "title": "Почему дети бросают музыку через полгода", "text": "и что с этим делать", "photo": "фото.jpg"},
  {"type": "text", "title": "Причина 1", "text": "Скучные упражнения без песни, которую ребёнок любит"},
  {"type": "list", "title": "Что помогает", "items": ["Песня с первого урока", "Выступление раз в полгода"]},
  {"type": "big", "text": "80% занятий: музыка, которую ребёнок выбрал сам"},
  {"type": "quote", "text": "Соня сама просит на урок", "author": "мама Сони, 9 лет"},
  {"type": "cta", "title": "Запишитесь на пробный урок", "text": "Ссылка в профиле"}
 ]
}
У любого слайда можно задать "tone": "base" | "accent" | "dark" | "surface". Номер слайда и подпись школы ставятся сами.
Создаёт рядом папку «слайды» с 01.png, 02.png… и лист «карусель_превью.png» для проверки.
Если текст не влезает даже мелким кеглем, в warnings будет «режь текст». Коды: 0 готово, 2 ошибка json, 6 нет фирстиля.
"""
import argparse
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

W, H, M = 1080, 1350, 96


def rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def light(h):
    r, g, b = rgb(h)
    return 0.299 * r + 0.587 * g + 0.114 * b > 150


class F:
    def __init__(self, brand):
        self.files = {r: str(studio.font_path(brand, r)) for r in ("head", "text")}
        self.c = {}

    def __call__(self, role, px):
        k = (role, px)
        if k not in self.c:
            self.c[k] = ImageFont.truetype(self.files[role], px)
        return self.c[k]


def wrap(font, text, max_w):
    lines = []
    for para in str(text).split("\n"):
        cur = ""
        for w in para.split(" "):
            t = (cur + " " + w).strip()
            if font.getlength(t) <= max_w or not cur:
                cur = t
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
    return lines


def fit(fonts, role, text, w, h, mx, mn, lh=1.15):
    px = mx
    while px >= mn:
        f = fonts(role, px)
        ls = wrap(f, text, w)
        if len(ls) * px * lh <= h and all(f.getlength(x) <= w for x in ls):
            return f, ls, px, True
        px -= 2
    f = fonts(role, mn)
    return f, wrap(f, text, w), mn, False


def draw_block(d, fonts, role, text, box, mx, mn, color, align="left", valign="top", lh=1.15):
    x, y, w, h = box
    f, ls, px, ok = fit(fonts, role, text, w, h, mx, mn, lh)
    total = len(ls) * px * lh
    yy = y + (h - total) / 2 if valign == "middle" else (y + h - total if valign == "bottom" else y)
    for ln in ls:
        xx = x + w / 2 if align == "center" else x
        d.text((xx, yy), ln, font=f, fill=color, anchor="ma" if align == "center" else "la")
        yy += px * lh
    return ok, y + total


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("carousel")
    a = ap.parse_args()
    brand = studio.load_brand()
    c = brand["colors"]
    fonts = F(brand)
    cp = Path(a.carousel)
    try:
        data = studio.typo_deep(json.loads(cp.read_text(encoding="utf-8")), skip=("photo", "type", "tone"))
    except Exception as e:  # noqa: BLE001
        studio.die(2, f"не читается {cp}: {e}")
    slides = data.get("slides", [])
    on_dark = c["bg"] if light(c["bg"]) else "#FFFFFF"
    tones = {"base": (c["bg"], c["text"], c["accent"], c["muted"]), "surface": (c["surface"], c["text"], c["accent"], c["muted"]),
             "accent": (c["accent"], c["accent_text"], c["accent_text"], c["accent_text"]), "dark": (c["dark"], on_dark, c["accent"], on_dark)}
    out = cp.parent / "слайды"
    out.mkdir(exist_ok=True)
    warnings, imgs = [], []
    for n, s in enumerate(slides, 1):
        t = s.get("type", "text")
        tone = s.get("tone") or {"big": "accent", "cta": "dark", "quote": "surface"}.get(t, "base")
        bg, fg, acc, mut = (rgb(v) for v in tones[tone])
        im = Image.new("RGB", (W, H), bg)
        d = ImageDraw.Draw(im)
        ok = True
        if t == "cover":
            photo = s.get("photo")
            src = next((p for p in (cp.parent / photo, studio.STUDIO / photo) if photo and p.exists()), None) if photo else None
            if photo and not src:
                warnings.append(f"слайд {n}: нет фото {photo}")
            if src:
                ph = ImageOps.fit(ImageOps.exif_transpose(Image.open(src)).convert("RGB"), (W, 700), centering=(0.5, 0.35))
                im.paste(ph, (0, 0))
                ok, _ = draw_block(d, fonts, "head", s.get("title", ""), (M, 760, W - 2 * M, 390), 96, 48, fg)
                if s.get("text"):
                    draw_block(d, fonts, "text", s["text"], (M, 1160, W - 2 * M, 90), 40, 26, mut)
            else:
                d.rectangle((M, 260, M + 120, 272), fill=acc)
                ok, _ = draw_block(d, fonts, "head", s.get("title", ""), (M, 320, W - 2 * M, 600), 120, 56, fg)
                if s.get("text"):
                    draw_block(d, fonts, "text", s["text"], (M, 960, W - 2 * M, 160), 48, 28, mut)
        elif t == "big":
            ok, _ = draw_block(d, fonts, "head", s.get("text", ""), (M, M + 40, W - 2 * M, H - 2 * M - 120), 120, 50, fg, "center", "middle")
        elif t == "list":
            draw_block(d, fonts, "head", s.get("title", ""), (M, 140, W - 2 * M, 220), 80, 44, fg)
            text = "\n".join("• " + i for i in s.get("items", []))
            ok, _ = draw_block(d, fonts, "text", text, (M, 420, W - 2 * M, 760), 56, 30, fg, lh=1.3)
        elif t == "quote":
            d.text((M, 180), "«", font=fonts("head", 220), fill=acc)
            ok, _ = draw_block(d, fonts, "text", s.get("text", ""), (M, 440, W - 2 * M, 560), 64, 32, fg)
            if s.get("author"):
                draw_block(d, fonts, "text", s["author"], (M, 1040, W - 2 * M, 80), 38, 24, mut)
        elif t == "cta":
            ok, _ = draw_block(d, fonts, "head", s.get("title", ""), (M, 300, W - 2 * M, 440), 100, 48, fg, "center", "middle")
            if s.get("text"):
                bw, bh, by = W - 2 * M - 120, 130, 820
                d.rounded_rectangle(((W - bw) // 2, by, (W + bw) // 2, by + bh), radius=65, fill=rgb(c["accent"]))
                draw_block(d, fonts, "head", s["text"], ((W - bw) // 2 + 30, by + 20, bw - 60, bh - 40), 48, 24,
                           rgb(c["accent_text"]), "center", "middle")
        else:  # text
            draw_block(d, fonts, "head", s.get("title", ""), (M, 160, W - 2 * M, 300), 88, 44, fg)
            ok, _ = draw_block(d, fonts, "text", s.get("text", ""), (M, 520, W - 2 * M, 660), 60, 30, fg, lh=1.3)
        if not ok:
            warnings.append(f"слайд {n}: текст не влезает, режь текст")
        foot = fonts("text", 30)
        d.text((M, H - 80), brand["school"], font=foot, fill=mut, anchor="ls")
        d.text((W - M, H - 80), f"{n}/{len(slides)}", font=foot, fill=mut, anchor="rs")
        p = out / f"{n:02d}.png"
        im.save(p)
        imgs.append(im)
    cols = min(len(imgs), 3) or 1
    tw, th = 360, 450
    rows = (len(imgs) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * tw + (cols + 1) * 16, rows * th + (rows + 1) * 16), (225, 225, 225))
    for i, im in enumerate(imgs):
        sheet.paste(im.resize((tw, th)), (16 + (i % cols) * (tw + 16), 16 + (i // cols) * (th + 16)))
    prev = cp.parent / "карусель_превью.png"
    sheet.save(prev)
    print(json.dumps({"ok": True, "folder": str(out), "preview": str(prev), "slides": len(imgs), "warnings": warnings},
                     ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
