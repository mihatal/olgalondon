#!/usr/bin/env python3
"""Проверка Студии: что стоит, чего не хватает и чем чинить. Ничего не меняет.

Запуск: .agents/run studio-setup/scripts/doctor.py   (Windows: .agents\\run.ps1 ...)
Код выхода 0, если всё в порядке, иначе 1.
"""
import importlib.util
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
import studio  # noqa: E402

rows = []


def row(ok, name, fix=""):
    rows.append({"ok": bool(ok), "name": name, "fix": fix})


setup_cmd = (r"powershell -ExecutionPolicy Bypass -File .agents\skills\studio-setup\scripts\setup.ps1"
             if studio.IS_WIN else "bash .agents/skills/studio-setup/scripts/setup.sh")

row(True, f"система: {'Windows' if studio.IS_WIN else 'Mac'}; распознавание речи: {studio.asr_backend()} ({studio.asr_speed_hint()})")
for t, why in (("ffmpeg", "видео и звук"), ("ffprobe", "видео и звук"), ("deno", "YouTube"),
               ("git", "публикация"), ("gh", "публикация"), ("node", "анимации Remotion"), ("npx", "анимации Remotion")):
    row(studio.tool(t, required=False), f"{t} ({why})", studio.install_hint(t))

mods = ["yt_dlp", "PIL", "numpy", "pptx", "mlx_whisper" if studio.APPLE_SILICON else "faster_whisper"]
missing = [m for m in mods if importlib.util.find_spec(m) is None]
row(not missing, "пакеты Python" + (f" (нет: {', '.join(missing)})" if missing else ""), setup_cmd)
row(studio.model_cached(), "модель распознавания речи скачана",
    (".agents\\run.ps1" if studio.IS_WIN else ".agents/run") + " transcribe/scripts/transcribe.py --warmup")
row(importlib.util.find_spec("demucs") is not None, "минусовки (по желанию)", "скилл minus: «поставь минусовки»")

brand = studio.load_brand(required=False)
if brand:
    fonts_ok = all((studio.STUDIO / brand["fonts"][r]["file"]).exists() for r in ("head", "text"))
    row(fonts_ok, f"фирстиль «{brand.get('school', '')}» и его шрифты", "скилл znakomstvo")
else:
    row(False, "фирстиль школы", "скилл znakomstvo: напиши «давай познакомимся»")

gh = studio.tool("gh", required=False)
if gh:
    r = subprocess.run([gh, "auth", "status"], capture_output=True, text=True)
    row(r.returncode == 0, "вход в GitHub для публикации", "скилл publish проведёт вход")

free = shutil.disk_usage(studio.STUDIO).free // 2**30
row(free >= 20, f"свободно {free} ГБ на диске", "освободить место: видео и рендеры занимают много, нужно от 20 ГБ")
row((studio.STUDIO / "AGENTS.md").exists(), "AGENTS.md в корне Студии", "распаковать архив заново")

for r in rows:
    print(("✓ " if r["ok"] else "✗ ") + r["name"] + ("" if r["ok"] else f"  →  {r['fix']}"))
bad = sum(not r["ok"] for r in rows if not r["name"].startswith("минусовки"))
print("—")
print(f"Итог: {len(rows) - bad} в порядке, {bad} требует внимания.")
print(json.dumps({"ok": bad == 0, "rows": rows}, ensure_ascii=False), file=sys.stderr)
sys.exit(0 if bad == 0 else 1)
