# Установка окружения Студии на Windows. Повторный запуск безопасен: ставится только недостающее.
# Запуск: powershell -ExecutionPolicy Bypass -File .agents\skills\studio-setup\scripts\setup.ps1
# Коды выхода: 0 готово · 10 нет winget · 1 прочая ошибка
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Agents = (Resolve-Path (Join-Path $PSScriptRoot "..\..\..")).Path
$env:UV_CACHE_DIR = Join-Path $Agents ".cache\uv"
$env:UV_PYTHON_INSTALL_DIR = Join-Path $Agents ".cache\python"
$env:HF_HOME = Join-Path $Agents ".cache\huggingface"
$links = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links"
function Refresh-Path {
  $m = [Environment]::GetEnvironmentVariable("Path", "Machine"); $u = [Environment]::GetEnvironmentVariable("Path", "User")
  $env:PATH = "$links;$u;$m"
}
Refresh-Path

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
  Write-Output "СТОП: нет программы winget. Открой Microsoft Store, найди «App Installer» (Установщик приложений), нажми «Обновить» или «Установить», затем вернись в Codex и напиши «запусти установку студии ещё раз»."
  exit 10
}

$pkgs = [ordered]@{ "ffmpeg" = "Gyan.FFmpeg"; "uv" = "astral-sh.uv"; "deno" = "DenoLand.Deno"; "git" = "Git.Git"; "gh" = "GitHub.cli"; "node" = "OpenJS.NodeJS.LTS" }
foreach ($k in $pkgs.Keys) {
  if (-not (Get-Command $k -ErrorAction SilentlyContinue)) {
    Write-Output ">> Ставлю $k ($($pkgs[$k]))"
    winget install --id $pkgs[$k] -e --accept-source-agreements --accept-package-agreements --silent
    Refresh-Path
    if (-not (Get-Command $k -ErrorAction SilentlyContinue)) {
      Write-Output "ОШИБКА: $k не появился после установки. Закрой и снова открой приложение ChatGPT, потом повтори установку."
      exit 1
    }
  }
}

$Py = Join-Path $Agents ".venv\Scripts\python.exe"
if (-not (Test-Path $Py)) {
  Write-Output ">> Создаю окружение Python в .agents\.venv"
  uv venv (Join-Path $Agents ".venv") --python 3.12
  if ($LASTEXITCODE -ne 0) { Write-Output "ОШИБКА: не удалось создать окружение."; exit 1 }
}
Write-Output ">> Ставлю пакеты (распознавание речи, YouTube, картинки, презентации)"
uv pip install --python $Py -r (Join-Path $Agents "requirements.txt")
if ($LASTEXITCODE -ne 0) { Write-Output "ОШИБКА: пакеты не поставились."; exit 1 }

Write-Output ">> Скачиваю модель распознавания речи (один раз, около 1,6 ГБ)"
& (Join-Path $Agents "run.ps1") transcribe/scripts/transcribe.py --warmup
if ($LASTEXITCODE -ne 0) { Write-Output "ОШИБКА: модель не скачалась. Проверь интернет и повтори."; exit 1 }

& (Join-Path $Agents "run.ps1") studio-setup/scripts/doctor.py
exit $LASTEXITCODE
