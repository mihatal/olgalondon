# Запуск скриптов Студии в её собственном окружении (Windows).
# Пример: .agents\run.ps1 transcribe/scripts/transcribe.py "Входящие\запись.m4a"
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Py = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $Py)) {
  Write-Error "Окружение Студии не установлено. Запусти: powershell -ExecutionPolicy Bypass -File .agents\skills\studio-setup\scripts\setup.ps1"
  exit 3
}
if ($args.Count -lt 1) { Write-Error "Использование: .agents\run.ps1 <скилл>/scripts/<скрипт>.py [аргументы]"; exit 2 }
$Script = Join-Path (Join-Path $Root "skills") $args[0]
if (-not (Test-Path $Script)) { Write-Error "Скрипт не найден: $Script"; exit 2 }
$rest = @(); if ($args.Count -gt 1) { $rest = $args[1..($args.Count - 1)] }
$links = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links"
$env:PATH = "$links;$env:PATH"
if (-not $env:HF_HOME) { $env:HF_HOME = Join-Path $Root ".cache\huggingface" }
$env:HF_HUB_DISABLE_TELEMETRY = "1"
$env:TORCH_HOME = Join-Path $Root ".cache\torch"
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"
& $Py $Script @rest
exit $LASTEXITCODE
