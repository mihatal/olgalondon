#!/bin/bash
# Установка окружения Студии на Mac. Повторный запуск безопасен: ставится только недостающее.
# Коды выхода: 0 готово · 10 нет Homebrew (ставится руками в Терминале) · 1 прочая ошибка
set -uo pipefail
AGENTS="$(cd "$(dirname "$0")/../../.." && pwd)"     # .../Студия/.agents
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export UV_CACHE_DIR="$AGENTS/.cache/uv"
export UV_PYTHON_INSTALL_DIR="$AGENTS/.cache/python"
export HF_HOME="$AGENTS/.cache/huggingface"
say() { printf '%s\n' "$*"; }

if ! command -v brew >/dev/null 2>&1; then
  cat <<'TXT'
СТОП: нет Homebrew. Его ставят один раз руками, потому что он спрашивает пароль от Mac.
1. Открой программу «Терминал».
2. Вставь и нажми Enter:
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
3. Введи пароль от Mac (буквы при вводе не видны, это нормально).
4. В конце Homebrew покажет две команды «Next steps»: выполни их.
5. Вернись в Codex и напиши «запусти установку студии ещё раз».
TXT
  exit 10
fi

need=()
for t in ffmpeg uv deno git gh; do command -v "$t" >/dev/null 2>&1 || need+=("$t"); done
if [ ${#need[@]} -gt 0 ]; then
  say ">> Ставлю через Homebrew: ${need[*]}"
  brew install "${need[@]}" || { say "ОШИБКА: brew install ${need[*]} не прошёл. Текст ошибки выше."; exit 1; }
fi

if [ ! -x "$AGENTS/.venv/bin/python" ]; then
  say ">> Создаю окружение Python в .agents/.venv"
  uv venv "$AGENTS/.venv" --python 3.12 || { say "ОШИБКА: не удалось создать окружение."; exit 1; }
fi
say ">> Ставлю пакеты (распознавание речи, YouTube, картинки, презентации)"
uv pip install --python "$AGENTS/.venv/bin/python" -r "$AGENTS/requirements.txt" || { say "ОШИБКА: пакеты не поставились."; exit 1; }

say ">> Скачиваю модель распознавания речи (один раз, около 1,6 ГБ)"
"$AGENTS/run" transcribe/scripts/transcribe.py --warmup || { say "ОШИБКА: модель не скачалась. Проверь интернет и повтори."; exit 1; }

"$AGENTS/run" studio-setup/scripts/doctor.py
