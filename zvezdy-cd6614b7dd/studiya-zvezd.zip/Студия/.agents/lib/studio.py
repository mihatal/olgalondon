"""Общие функции Студии: пути, поиск ffmpeg на Mac и Windows, распознавание речи, бренд.

Подключение из скрипта скилла:
    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "lib"))
    import studio
"""
import json
import os
import platform
import shutil
import sys
from pathlib import Path

AGENTS = Path(__file__).resolve().parents[1]          # .../Студия/.agents
STUDIO = AGENTS.parent                                 # .../Студия
BRAND_DIR = STUDIO / "Бренд"
BRAND_JSON = BRAND_DIR / "brand.json"

IS_MAC = sys.platform == "darwin"
IS_WIN = os.name == "nt"
APPLE_SILICON = IS_MAC and platform.machine() == "arm64"


def die(code, msg):
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False))
    print("ОШИБКА: " + msg, file=sys.stderr)
    sys.exit(code)


def install_hint(name):
    if IS_WIN:
        return {"ffmpeg": "winget install Gyan.FFmpeg", "ffprobe": "winget install Gyan.FFmpeg",
                "git": "winget install Git.Git", "gh": "winget install GitHub.cli"}.get(name, f"winget install {name}")
    return f"brew install {'ffmpeg' if name == 'ffprobe' else name}"


def tool(name, required=True):
    """Путь к программе. Ищет в PATH и в местах, куда ставят Homebrew и winget."""
    exe = name + (".exe" if IS_WIN else "")
    cands = [shutil.which(name)]
    if IS_WIN:
        la = os.environ.get("LOCALAPPDATA", "")
        cands += [os.path.join(la, "Microsoft", "WinGet", "Links", exe)]
        pk = Path(la) / "Microsoft" / "WinGet" / "Packages"
        if pk.exists():
            cands += [str(p) for p in pk.glob(f"*/**/bin/{exe}")]
        cands += [rf"C:\Program Files\Git\cmd\{exe}", rf"C:\Program Files\GitHub CLI\{exe}"]
    else:
        cands += [f"/opt/homebrew/bin/{name}", f"/usr/local/bin/{name}"]
    for c in cands:
        if c and os.path.exists(c):
            return c
    if required:
        die(3, f"{name} не найден. Поставь: {install_hint(name)}")
    return None


# ---------- распознавание речи ----------
# Mac на M-процессоре: MLX (быстро, час записи ≈ 5 минут).
# Windows и Mac на Intel: faster-whisper на процессоре (медленнее, час записи ≈ 30–60 минут).
MLX_MODEL = "mlx-community/whisper-large-v3-turbo"
FW_MODEL = "large-v3-turbo"


def asr_backend():
    return "mlx" if APPLE_SILICON else "faster-whisper"


def asr_speed_hint():
    return "час записи ≈ 5 минут" if APPLE_SILICON else "час записи ≈ 30–60 минут, компьютер поработает сам"


def transcribe(audio, language=None, prompt=None, word_timestamps=True):
    """Возвращает {'language', 'segments': [{start,end,text,words:[{start,end,word,probability}]}]}."""
    if APPLE_SILICON:
        import mlx_whisper
        return mlx_whisper.transcribe(
            str(audio), path_or_hf_repo=MLX_MODEL, language=language,
            word_timestamps=word_timestamps, condition_on_previous_text=False,
            hallucination_silence_threshold=2.0, initial_prompt=prompt or None, verbose=None)
    from faster_whisper import WhisperModel
    model = WhisperModel(FW_MODEL, device="cpu", compute_type="int8",
                         download_root=str(AGENTS / ".cache" / "whisper"))
    segs, info = model.transcribe(
        str(audio), language=language, word_timestamps=word_timestamps,
        condition_on_previous_text=False, initial_prompt=prompt or None,
        vad_filter=False, hallucination_silence_threshold=2.0 if word_timestamps else None)
    out = []
    for s in segs:
        words = [{"start": w.start, "end": w.end, "word": w.word, "probability": w.probability}
                 for w in (s.words or [])]
        out.append({"start": s.start, "end": s.end, "text": s.text, "words": words})
    return {"language": info.language, "segments": out}


def warmup():
    """Скачать модель распознавания один раз."""
    if APPLE_SILICON:
        import mlx_whisper
        import numpy as np
        mlx_whisper.transcribe(np.zeros(16000, dtype=np.float32), path_or_hf_repo=MLX_MODEL, verbose=None)
        return MLX_MODEL
    from faster_whisper import WhisperModel
    WhisperModel(FW_MODEL, device="cpu", compute_type="int8", download_root=str(AGENTS / ".cache" / "whisper"))
    return FW_MODEL


def model_cached():
    if APPLE_SILICON:
        hf = Path(os.environ.get("HF_HOME", AGENTS / ".cache" / "huggingface"))
        return (hf / "hub" / "models--mlx-community--whisper-large-v3-turbo").exists()
    return any((AGENTS / ".cache" / "whisper").glob("models--*whisper-large-v3-turbo*"))


# ---------- бренд ----------
def load_brand(required=True):
    """brand.json, который пишет скилл znakomstvo. Без него навыки не делают дизайн."""
    if not BRAND_JSON.exists():
        if required:
            die(6, "Фирстиль ещё не задан: нет Бренд/brand.json. Сначала скилл znakomstvo («давай познакомимся»).")
        return None
    with open(BRAND_JSON, encoding="utf-8") as f:
        b = json.load(f)
    for role in ("head", "text"):
        p = STUDIO / b["fonts"][role]["file"]
        if not p.exists():
            die(3, f"нет файла шрифта {p}. Запусти: .agents/run znakomstvo/scripts/get_font.py \"{b['fonts'][role]['family']}\"")
    return b


def font_path(brand, role):
    return STUDIO / brand["fonts"][role]["file"]


# ---------- типографика ----------
import re as _re

_SHORT = ("а и в во с со к ко о об у не ни но да по за из от до на для без при под над что как или "
          "the a an to of in on at by for and or is").split()
_SHORT_RE = _re.compile(r"(?<![\w-])(" + "|".join(sorted(_SHORT, key=len, reverse=True)) + r") ", _re.IGNORECASE)


def typo(text):
    """Неразрывный пробел после коротких слов и перед тире: предлоги не висят в конце строки."""
    if not isinstance(text, str):
        return text
    t = _SHORT_RE.sub(lambda m: m.group(1) + " ", text)
    t = _SHORT_RE.sub(lambda m: m.group(1) + " ", t)   # второй проход для «и в»
    t = t.replace(" — ", " — ").replace(" – ", " – ")
    t = _re.sub(r"(?<![\w-])([Пп]о|[Кк]ое|[Вв]о)-(?=\w)", lambda m: m.group(1) + "-\u2060", t)  # «по-английски» не рвётся
    return t


def typo_deep(obj, skip=("answer", "bucket", "speak", "speakSide", "mode", "set", "direction", "targets",
                         "photo", "image", "audio", "src", "img", "type", "tone", "logo", "front")):
    """Типографика по всем строкам в данных, кроме служебных полей."""
    if isinstance(obj, dict):
        return {k: (v if k in skip else typo_deep(v, skip)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [typo_deep(v, skip) for v in obj]
    return typo(obj)
